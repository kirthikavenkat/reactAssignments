using Entity.Models;
using Entity.Data;
using Entity.Dto;
using Microsoft.EntityFrameworkCore;
using Contracts.IRepository;

namespace Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly EventContext _context;

        public AdminRepository(EventContext context)
        {
            _context = context;
        }

        public async Task ImportAdminsAsync(IEnumerable<Admin> admins)
        {
            await _context.Admin!.AddRangeAsync(admins);
            await _context.SaveChangesAsync();
        }

        public async Task<List<AdminDto>> GetAllAdminsAsync()
        {
            return await _context.Admin!.Select(x => new AdminDto()
            {
                Id = x.Id,
                Name = x.Name
            }).ToListAsync();
        }
    }
}
