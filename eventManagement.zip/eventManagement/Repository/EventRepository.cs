using Entity.Data;
using Entity.Dto;
using Entity.Models;
using Microsoft.EntityFrameworkCore;
using Contracts.IRepository;

namespace Repository
{
    public class EventRepository : IEventRepository
    {
        private readonly EventContext _context;

        public EventRepository(EventContext context)
        {
            _context = context;
        }

        public async Task<List<EventDto>> GetAllEventsAsync()
        {
            return await _context.Event!.Select(x => new EventDto()
            {
                EventId = x.EventId,
                EventName = x.EventName,
                EventDescription = x.EventDescription,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                CreatedOn = x.CreatedOn,
                UpdatedOn = x.UpdatedOn
            }).ToListAsync();
        }
        public async Task<List<EventDto>> GetPastEventsAsync()
        {
            DateTime currentDate = DateTime.UtcNow;
            return await _context.Event!.Where(x => x.EndDate < currentDate).Select(x => new EventDto()
            {
                EventId = x.EventId,
                EventName = x.EventName,
                EventDescription = x.EventDescription,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                CreatedOn = x.CreatedOn,
                UpdatedOn = x.UpdatedOn
            }).ToListAsync();
        }
        public async Task<List<EventDto>> GetUpcomingEventsAsync()
        {
            DateTime currentDate = DateTime.UtcNow;
            return await _context.Event!.Where(x => x.StartDate >= currentDate).Select(x => new EventDto()
            {
                EventId = x.EventId,
                EventName = x.EventName,
                EventDescription = x.EventDescription,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                CreatedOn = x.CreatedOn,
                UpdatedOn = x.UpdatedOn
            }).ToListAsync();
        }
        public async Task CreateEventAsync(Event eventEntity)
        {
            _context.Event?.Add(eventEntity);
            await _context.SaveChangesAsync();
        }
  public async Task ImportAttendeesAsync(IEnumerable<EventAttendee> attendees)
        {
            await _context.EventAttendees!.AddRangeAsync(attendees);
            await _context.SaveChangesAsync();
        }

    }
}
