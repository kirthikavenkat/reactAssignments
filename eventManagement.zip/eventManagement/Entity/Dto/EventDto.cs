using System;
using System.ComponentModel.DataAnnotations;
using Entity.Models;

namespace Entity.Dto
{
    public class EventDto
    {
        public Guid EventId { get; set; }
        
        [Required(ErrorMessage = "Event name is required")]
        public string EventName { get; set; } = "";

        public string EventDescription { get; set; } = "";

        [Required(ErrorMessage = "Start date is required")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End date is required")]
        public DateTime EndDate { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

        public DateTime UpdatedOn { get; set; } = DateTime.UtcNow;

        public IList<Attendee>? Attendee {get; set;}
    }
}
