using System;
using System.ComponentModel.DataAnnotations;

namespace Entity.Dto
{
    public class AdminDto
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Admin name is required")]
        public string Name { get; set; } = "";

    }
}
