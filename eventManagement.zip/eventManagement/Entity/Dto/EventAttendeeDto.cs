using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entity.Dto
{
    public class EventAttendeeDto
    {

        public Guid EventId { get; set; }
        public Guid AttendeeId { get; set; }
    }
}
