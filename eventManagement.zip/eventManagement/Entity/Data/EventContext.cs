using Entity.Models;
using Microsoft.EntityFrameworkCore;

namespace Entity.Data
{


    public class EventContext : DbContext
    {
        public EventContext(DbContextOptions<EventContext> options)
        : base(options)
        {

        }
        public DbSet<Admin>? Admin { get; set; }
        public DbSet<Event>? Event { get; set; }
        public DbSet<Attendee>? Attendee { get; set; }
        public DbSet<EventAttendee>? EventAttendees { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventAttendee>()
                .HasKey(ea => new { ea.EventId, ea.AttendeeId });

            modelBuilder.Entity<EventAttendee>()
                .HasOne<Event>()
                .WithMany()
                .HasForeignKey(ea => ea.EventId);

            modelBuilder.Entity<EventAttendee>()
                .HasOne<Attendee>()
                .WithMany()
                .HasForeignKey(ea => ea.AttendeeId);

            modelBuilder.Entity<EventAttendee>()
                .ToTable("EventAttendees");

            base.OnModelCreating(modelBuilder);
        }



    }

}