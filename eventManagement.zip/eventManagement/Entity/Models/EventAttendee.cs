using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entity.Models
{
    public class EventAttendee
    {
        [Column("event_id")]
        public Guid EventId { get; set; }
        [Column("attendee_id")]
        public Guid AttendeeId { get; set; }
    }
}
