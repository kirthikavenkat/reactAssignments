using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entity.Models{
    public class Event{

      [Column("id")]
      public Guid EventId {get;set;}
      [Required]
      [Column("name")]
      public string EventName {get; set;} = "";
      [Required]
      [Column("description")]
      public string EventDescription {get; set;} = "";
      [Required]
      [Column("start_date")]
      public DateTime StartDate {get; set;}
      [Required]
      [Column("end_date")]
      public DateTime EndDate {get; set;}
      [Required]
      [Column("created_on")]
      public DateTime CreatedOn {get; set;} = DateTime.UtcNow;
      [Required]
      [Column("updated_on")]
      public DateTime UpdatedOn {get; set;} = DateTime.UtcNow;

      public IList<Attendee>? Attendees {get; set;}
    }
}