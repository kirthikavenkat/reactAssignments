using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entity.Models
{
    public class Attendee
    {
        [Column("id")]
        public Guid Id { get; set; }

        [Required]
        [Column("name")]
        public string Name { get; set; } = "";

        [Required]
        [Column("address")]
        public string Address { get; set; } = "";

        [Required]
        [Column("phone_number")]
        public string PhoneNumber { get; set; } = "";
        public IList<Event>? Events {get; set;} 
    }
}
