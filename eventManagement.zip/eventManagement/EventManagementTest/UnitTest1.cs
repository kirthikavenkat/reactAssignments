using Entity.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Xunit;
using Moq;
using Contracts.IRepository;
using Contracts.IServices;
using eventManagement.Controllers;

namespace AdminApiTest
{
    public class GetAdminsTest
    {

        // Get all admins test
        [Fact]
        public async Task GetAllAdminsTesting()
        {
            // Arrange
            var expectedAdmins = new List<AdminDto>
            {
                new AdminDto { Id = 1, Name = "John Doe" },
                new AdminDto { Id = 2, Name = "Jane Smith" }
            };

            var adminServiceMock = new Mock<IAdminService>();
            adminServiceMock.Setup(s => s.GetAllAdminsAsync())
                .ReturnsAsync(expectedAdmins);

            var adminController = new AdminController(adminServiceMock.Object);

            // Act
            var result = await adminController.GetAllAdminsAsync();

            // Assert
            Assert.IsType<OkObjectResult>(result);
            Assert.IsType<List<AdminDto>>(((OkObjectResult)result).Value);
            Assert.Equal(200, ((OkObjectResult)result).StatusCode);
        }

    }
}
