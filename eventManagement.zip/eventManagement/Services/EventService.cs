using Entity.Dto;
using Entity.Data;
using Entity.Models;
using Microsoft.EntityFrameworkCore;
using Contracts.IServices;
using Contracts.IRepository;

namespace Services
{
    public class EventService : IEventService
    {
        private readonly IEventRepository _eventRepository;

        private readonly EventContext? _context;
        public EventService(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        public async Task<List<EventDto>> GetAllEventsAsync()
        {
            return await _eventRepository.GetAllEventsAsync();
        }
        public async Task<List<EventDto>> GetPastEventsAsync()
        {
            return await _eventRepository.GetPastEventsAsync();
        }
        public async Task<List<EventDto>> GetUpcomingEventsAsync()
        {
            return await _eventRepository.GetUpcomingEventsAsync();
        }
        public async Task<Guid> AddNewEventAsync(EventDto eventDto)
        {
            Guid eventId = Guid.NewGuid();
            eventDto.EventId = eventId;
            eventDto.CreatedOn = DateTime.UtcNow;
            eventDto.UpdatedOn = DateTime.UtcNow;
            Event eventEntity = new Event
            {
                EventId = eventDto.EventId,
                EventName = eventDto.EventName,
                EventDescription = eventDto.EventDescription,
                StartDate = eventDto.StartDate,
                EndDate = eventDto.EndDate,
                CreatedOn = eventDto.CreatedOn,
                UpdatedOn = eventDto.UpdatedOn
            };

            await _eventRepository.CreateEventAsync(eventEntity);
            return eventId;
        }

        public async Task<IEnumerable<EventAttendeeDto>> GetConflictingEvents(IEnumerable<EventAttendeeDto> attendees)
        {
            var conflictingAttendees = new List<EventAttendeeDto>();

            foreach (var attendee in attendees)
            {
                var conflictingEvent = await _context.Event
                    .FirstOrDefaultAsync(e => e.EventId == attendee.EventId && e.StartDate <= DateTime.Now && e.EndDate >= DateTime.Now);

                if (conflictingEvent != null)
                {
                    conflictingAttendees.Add(attendee);
                }
            }

            return conflictingAttendees;
        }
        private bool IsTimeConflict(Event event1, Event event2)
        {
            return event1.StartDate < event2.EndDate && event2.StartDate < event1.EndDate;
        }

        public async Task ImportAttendees(IEnumerable<EventAttendeeDto> attendeeDTOs)
        {
            var attendees = attendeeDTOs.Select(u => new EventAttendee { EventId = u.EventId, AttendeeId = u.AttendeeId });
            await _eventRepository.ImportAttendeesAsync(attendees);
        }

    }
}
