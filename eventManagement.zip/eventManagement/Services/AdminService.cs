using Entity.Dto;
using Entity.Data;
using Entity.Models;
using Repository;
using Microsoft.EntityFrameworkCore;
using Contracts.IServices;
using Contracts.IRepository;

namespace Services
{

    public class AdminService : IAdminService
    {
        private readonly IAdminRepository _adminRepository;

        public AdminService(IAdminRepository adminRepository)
        {
            _adminRepository = adminRepository;
        }
        public async Task ImportAdmins(IEnumerable<AdminDto> adminDTOs)
        {
            var admins = adminDTOs.Select(u => new Admin { Id = u.Id, Name = u.Name });
            await _adminRepository.ImportAdminsAsync(admins);
        }
        public async Task<List<AdminDto>> GetAllAdminsAsync()
        {
            return await _adminRepository.GetAllAdminsAsync();
        }
    }
}