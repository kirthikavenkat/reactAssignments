using Entity.Dto;
using Entity.Models;

namespace Contracts.IServices
{
    public interface IEventService
    {
        Task<List<EventDto>> GetAllEventsAsync();
        Task<Guid> AddNewEventAsync(EventDto eventDto);
        Task<List<EventDto>> GetPastEventsAsync();
        Task<List<EventDto>> GetUpcomingEventsAsync();
        Task ImportAttendees(IEnumerable<EventAttendeeDto> attendeeDTOs);
       Task<IEnumerable<EventAttendeeDto>> GetConflictingEvents(IEnumerable<EventAttendeeDto> attendees);
    }

}