using Entity.Dto;
using Entity.Models;

namespace Contracts.IServices
{
    public interface IAdminService
    {
        Task ImportAdmins(IEnumerable<AdminDto> adminDTOs);
        Task<List<AdminDto>> GetAllAdminsAsync();
    }
}