using Entity.Dto;
using Entity.Models;

namespace Contracts.IRepository{
    public interface IEventRepository{
Task CreateEventAsync(Event eventEntity);
Task<List<EventDto>> GetAllEventsAsync();
Task<List<EventDto>> GetPastEventsAsync();
Task<List<EventDto>> GetUpcomingEventsAsync();
Task ImportAttendeesAsync(IEnumerable<EventAttendee> attendees);
    }
}