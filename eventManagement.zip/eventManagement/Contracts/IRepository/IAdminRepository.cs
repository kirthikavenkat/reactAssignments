using Entity.Dto;
using Entity.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Contracts.IRepository
{
    public interface IAdminRepository
    {
        Task ImportAdminsAsync(IEnumerable<Admin> admins);
        Task<List<AdminDto>> GetAllAdminsAsync();
    }
}
