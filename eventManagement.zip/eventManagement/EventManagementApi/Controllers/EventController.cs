using Entity.Dto;
using Repository;
using Services;
using Microsoft.AspNetCore.Mvc;
using Contracts.IServices;

namespace EventManagement.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]

    public class EventController : ControllerBase
    {

        private readonly IEventService _eventService;
        public EventController(IEventService eventService)
        {
            _eventService = eventService;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _eventService.GetAllEventsAsync();
            return Ok(events);
        }
        [HttpGet("{eventType}")]
        public async Task<IActionResult> GetEvents([FromRoute] string eventType)
        {
            if (eventType == "past")
            {
                var events = await _eventService.GetPastEventsAsync();
                return Ok(events);
            }
            else if (eventType == "upcoming")
            {
                var events = await _eventService.GetUpcomingEventsAsync();
                return Ok(events);
            }
            return BadRequest("Unsupported event type.");
        }

        [HttpPost("")]
        public async Task<IActionResult> AddNewEvent([FromBody] EventDto eventDto)
        {
            var id = await _eventService.AddNewEventAsync(eventDto);
            return CreatedAtAction(nameof(GetAllEvents), new
            {
                id = id,
                controller = "event"
            }, id
            );
        }

        [HttpPost("eventAttendees")]
        public async Task<IActionResult> ImportAttendeesFromCSV([FromForm] IFormFile file)
        {
            try
            {
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    var attendees = new List<EventAttendeeDto>();

                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        var attendee = new EventAttendeeDto
                        {
                            EventId = Guid.Parse(values[0]),
                            AttendeeId = Guid.Parse(values[1])
                        };

                        attendees.Add(attendee);
                    }

                    var conflictingAttendees = await _eventService.GetConflictingEvents(attendees);

                    if (conflictingAttendees.Any())
                    {
                        var conflictedAttendeesNames = conflictingAttendees.Select(a => a.AttendeeId);
                        return Conflict($"The following attendees have conflicts: {string.Join(", ", conflictedAttendeesNames)}");
                    }

                    await _eventService.ImportAttendees(attendees);

                    return Ok("Attendees imported successfully");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error importing attendees: {ex.Message}");
            }
        }
    }
}
