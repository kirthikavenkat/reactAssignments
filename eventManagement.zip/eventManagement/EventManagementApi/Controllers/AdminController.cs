using Entity.Dto;
using Entity.Models;
using Services;
using Microsoft.AspNetCore.Mvc;
using Contracts.IRepository;
using Contracts.IServices;

namespace eventManagement.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AdminController : ControllerBase
{
    private readonly IAdminService _adminService;

    public AdminController(IAdminService adminService)
    {
        _adminService = adminService;
    }

    [HttpPost("import")]
    public async Task<IActionResult> ImportAdminsFromCSV([FromForm] IFormFile file)
    {
        try
        {
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                var admins = new List<AdminDto>();

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    var admin = new AdminDto
                    {
                        Id = int.Parse(values[0]),
                        Name = values[1]
                    };

                    admins.Add(admin);
                }

                await _adminService.ImportAdmins(admins);

                return Ok("Admins imported successfully");
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error importing admins: {ex.Message}");
        }
    }

    [HttpGet("")]
    public async Task<IActionResult> GetAllAdminsAsync()
    {
        var admins = await _adminService.GetAllAdminsAsync();
        return Ok(admins);
    }

}
