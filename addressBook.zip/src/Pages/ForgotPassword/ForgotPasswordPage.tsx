import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AddressBook from "../../Assets/AddressBook.png";
import EmailIcon from "../../Assets/EmailIcon.svg";
import {
  Addressbkimg,
  ForgotPageButton,
  FullContainer,
  Heading1,
  Heading2,
  Image,
  InputText,
  InputContainer,
  MainContainer,
  MainText,
  TitleContainer,
  WarningMessage,
} from "./ForgotPasswordPage.style";
const ForgotPassword = () => {
  /*Validation*/
  const [email, setEmail] = useState("");

  const [message, setMessage] = useState("");
  const emailRegex = /^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+.[a-zA-Z]$/;
  const validateEmail = (event: { target: { value: any } }) => {
    const email = event.target.value;
    setEmail(email);
    if (emailRegex.test(email)) {
      setMessage(" ");
    } else {
      setMessage("Please enter a valid email!");
    }
  };

  /*Send mail function*/
  const sendEmail = () => {
    if (email === "") {
      setMessage("Email is required!");
    } else if (emailRegex.test(email)) {
      toast.success(
        "Email sent successfully! Please check yout inbox and follow the instructions.",
        {
          position: toast.POSITION.TOP_RIGHT,
        }
      );
    }
  };
  return (
    <FullContainer>
      <TitleContainer>
        <Addressbkimg src={AddressBook} />
        <Heading1>Address Book</Heading1>
      </TitleContainer>

      <MainContainer>
        <Heading2>Forgot Password?</Heading2>
        <MainText>
          <div>
            Enter your email address or username associated to your account.
          </div>
          <div> We will email you a link to reset your password</div>
        </MainText>

        <InputContainer>
          <Image src={EmailIcon}></Image>
          <InputText
            id="email"
            onChange={(e) => validateEmail(e)}
            placeholder="Email"
          ></InputText>
          <WarningMessage>{message}</WarningMessage>
          <WarningMessage id="success"></WarningMessage>
        </InputContainer>

        <ForgotPageButton color="#428bca" onClick={sendEmail}>
          Send
        </ForgotPageButton>
        <ToastContainer />
      </MainContainer>
    </FullContainer>
  );
};
export default ForgotPassword;
