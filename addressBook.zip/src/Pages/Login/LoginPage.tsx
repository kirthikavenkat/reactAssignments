import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AddressBook from "../../Assets/AddressBook.png";
import EmailIcon from "../../Assets/EmailIcon.svg";
import PasswordIcon from "../../Assets/PasswordIcon.svg";
import {
  Addressbkimg,
  LoginPageButton,
  ButtonContainer,
  FullContainer,
  Heading1,
  Heading2,
  Image,
  InputText,
  InputContainer,
  InputContainer1,
  MainContainer,
  TitleContainer,
  WarningMessage,
} from "./LoginPage.style";

const Login = () => {
  interface error {
    email: string;
    password: string;
  }
  const [emailValue, setEmail] = useState("");
  const [passwordValue, setPassword] = useState("");
  const [errorLogin, setError] = useState<error>({ email: "", password: "" });

  //setting the email and password value
  const handleEmailChange = (e: any) => {
    setEmail(e.target.value);
  };
  const handlePasswordChange = (e: any) => {
    setPassword(e.target.value);
  };

  /*Sign in*/
  const signin = () => {
    if (
      emailValue === "kirthikavenkat29@gmail.com" &&
      passwordValue === "kir29"
    ) {
      navigate("/home");
    }
    if (passwordValue === "" && emailValue === "") {
      setError({
        email: "Email is required",
        password: "Password is required",
      });
    } else if (passwordValue === "" && emailValue !== "") {
      setError({ email: "", password: "Password is required" });
    } else if (passwordValue !== "" && emailValue === "") {
      setError({ email: "Email is required", password: "" });
    } else if (emailValue !== "" && passwordValue !== "") {
      setError({ email: "", password: "Incorrect Email id or Password" });
    }
  };

  /*Reset function*/
  const reset = () => {
    setEmail("");
    setPassword("");
  };
  const navigate = useNavigate();

  /*Email validation*/
  const emailRegex = /^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+.[a-zA-Z]$/;
  const validateEmail = (event: { target: { value: any } }) => {
    const email = event.target.value;
    if (emailRegex.test(email)) {
      setError({ email: "", password: "" });
    } else {
      setError({ email: "Please enter a valid email", password: "" });
    }
  };

  return (
    <FullContainer>
      <TitleContainer>
        <Addressbkimg src={AddressBook} />
        <Heading1>Address Book</Heading1>
      </TitleContainer>

      <MainContainer>
        <Heading2>Login to your account</Heading2>
        <InputContainer1>
          <Image src={EmailIcon}></Image>
          <InputText
            id="email"
            onBlurCapture={validateEmail}
            value={emailValue}
            onChange={(e) => handleEmailChange(e)}
            placeholder="Email"
            required
          ></InputText>
          {errorLogin.email ? (
            <WarningMessage>{errorLogin.email}</WarningMessage>
          ) : (
            " "
          )}
        </InputContainer1>

        <InputContainer>
          <Image src={PasswordIcon}></Image>
          <InputText
            id="password"
            placeholder="Password"
            value={passwordValue}
            required
            type={"password"}
            onChange={(e) => handlePasswordChange(e)}
          ></InputText>
          {errorLogin.password ? (
            <WarningMessage>{errorLogin.password}</WarningMessage>
          ) : (
            ""
          )}
        </InputContainer>

        <ButtonContainer>
          <LoginPageButton color="#428bca" onClick={signin}>
            Sign In
          </LoginPageButton>
          <LoginPageButton color="#f0ad4e" onClick={reset}>
            Reset
          </LoginPageButton>
        </ButtonContainer>
      </MainContainer>

      <Link
        style={{ position: "relative", right: "-140px", top: "20px" }}
        to="/forgot"
      >
        Forgot Password?
      </Link>
    </FullContainer>
  );
};
export default Login;
