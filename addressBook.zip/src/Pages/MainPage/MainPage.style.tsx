import styled from "styled-components";

export const MainContent = styled.div`
  z-index: 1;
  width: 90%;
  margin-top: -10px;
  padding-left: 15%;
  @media (max-width: 776px) {
    padding-left: 2%;
  }
`;
export const PageContent = styled.div`
  display: flex;
  flex-direction: row;
  width: full;
`;
export const PagePathStyle = styled.div`
  height: 25px;
  width: 88%;
  margin: 10px 10px 10px 20px;
  position: relative;
  z-index: 20;
  display: flex;
  padding: 15px;
  align-items: center;
  flex-direction: row;
  gap: 8px;
  background-color: #f5f5f5;
  border-radius: 5px;
  top: 140px;
  @media (max-width: 930px) {
    top:200px;
  }
  @media (max-width: 768px) {
    width: 75%;
    margin-left: 22%;
  }
  @media (max-width: 425px) {
    top: 200px;
    width: 80%;
    margin-left: 15px;
  }
  @media (max-width: 375px) {
    top: 150px;
    margin-top: 20px;
    margin-left: 15px;
  }
  @media (max-width: 325px) {
    margin-left: 15px;
    width: 80%;
  }
  @media (max-width: 280px) {
    margin-top: 20px;
    margin-left: 15px;
  }
`;
