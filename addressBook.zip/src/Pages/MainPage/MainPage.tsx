import React, { useState } from "react";
import NavbarComponent from "../../Components/Navbar/Navbar";
import SidebarComponent from "../../Components/Sidebar/Sidebar";
import CreateAddressBook from "../../Container/CreateAddressBook/CreateAddressBook";
import { MainContent, PageContent , PagePathStyle} from "./MainPage.style";
import ListAddress from "../../Container/ListAddressBook/ListAddressBook";
import { ToastContainer } from "react-toastify";
import { addressBook } from "../../Container/CreateAddressBook/CreateAddressBook";

interface Breadcrumb {
  text: string;
  url: string;
}

//Page path
const MainPage = () => {
  const initialBreadcrumbs = [{ text: "Home / ", url: "/" }];

  //state to set and unset create and list component
  const [showCreateAddress, setShowCreateAddress] = useState(false);
  const [showListAddress, setShowListAddress] = useState(true);

  const [formData, setformData] = useState<addressBook | any>([]);
  const [editDataID, setEditDataID] = useState(null);
  const [editValue, setEditValue] = useState<any>({
    address: [{}],
    email: [{}],
    lastname: "",
    name: "",
    phone: [{}],
  });

  const [breadcrumbItems, setBreadcrumbItems] =
    useState<Breadcrumb[]>(initialBreadcrumbs);

  const [successMessage, setSuccessMessage] = useState("");

  const handleFormDataChange = (data: any, message: string) => {
    const value = data;
    if (editDataID === null) {
      setformData([...formData, value]);
      setSuccessMessage("Address book added successfully");
    } else {
      formData[editDataID] = data;
      setSuccessMessage("Data updated successful");
    }
    setEditDataID(null);
    setEditValue({
      address: [{}],
      email: [{}],
      lastname: "",
      name: "",
      phone: [{}],
    });
    setShowListAddress(true);
    setShowCreateAddress(false);
  };

  const handleCreateAddress = () => {
    setShowCreateAddress(true);
    setEditDataID(null);
  };

  return (
    <React.Fragment>
      <NavbarComponent
        setShowCreateAddress={setShowCreateAddress}
        setShowListAddress={setShowListAddress}
      />
      <PageContent>
        <SidebarComponent
          setShowCreateAddress={setShowCreateAddress}
          setShowListAddress={setShowListAddress}
        />
        <MainContent>
          <PagePathStyle>
            {breadcrumbItems.map((item: any, index: any) => (
              <>
                <span key={index}>{item.text}</span>
              </>
            ))}
          </PagePathStyle>
          <ToastContainer />
          {showListAddress && (
            <ListAddress
              editValue={editValue}
              formData={formData}
              toastMessage={successMessage}
              setToastMessage={setSuccessMessage}
              handleCreateAddress={handleCreateAddress}
              setEditDataID={setEditDataID}
              setEditValue={setEditValue}
              setShowCreateAddress={setShowCreateAddress}
              setShowListAddress={setShowListAddress}
              setformData={setformData}
              breadcrumbItems={breadcrumbItems}
              setBreadcrumbItems={setBreadcrumbItems}
            />
          )}
          {showCreateAddress && (
            <CreateAddressBook
              formData={formData}
              onFormDataChange={handleFormDataChange}
              setShowCreateAddress={setShowCreateAddress}
              setShowListAddress={setShowListAddress}
              toEdit={editValue}
              editDataID={editDataID}
              breadcrumbItems={breadcrumbItems}
              setBreadcrumbItems={setBreadcrumbItems}
            />
          )}
        </MainContent>
      </PageContent>
    </React.Fragment>
  );
};

export default MainPage;
