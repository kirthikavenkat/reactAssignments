import React, { useState, useEffect, FormEvent} from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ReactComponent as DiscardIcon } from "../../Assets/DiscardIcon.svg";
import Select from "../../Components/Select/Select";
import {
  AddPlusButton,
  CreatePageButton,
  ContainerWarn,
  DetailsCreate,
  FullContainerCreate,
  GetDetails1,
  DetailsContainer,
  DiscardContainer,
  Heading3,
  HeadingPlusButton,
  InputName,
  MainContainerCreate,
  MainContent,
  PageContent,
  SubmitForm,
  TitleContainer,
  ValidateWarn,
  InputLastName,
} from "./CreateAddressBook.style";
import InputField from "../../Components/Input/Input";

//Interfaces
export interface addressBook {
  address: newaddress[];
  email: newemail[];
  lastname: string;
  name: string;
  phone: newphone[];
}
export interface newemail{
  email:string;
  emailtype:string;
}
export interface newphone {
  phone:string;
  phonetype:string;
}
export interface newaddress {
  city: string;
  country: string;
  line1: string;
  line2: string;
  state: string;
  zipcode: string;
  addresstype:string
}

//Initial empty data
const data = [{
  name: "",
  lastname: "",
  email: [{
    email: "",
    emailtype: ""
  }],
  address: [{
    line1: "",
    line2: "",
    city: "",
    state: "",
    country: "",
    zipcode: "",
    addresstype:""
  }],
  phone: [{
    phone: "",
    phonetype : ""
  }]
}]

//Options for the select component
const EmailTypeOptions = [
  { label: "Email Type", disabled: true },
  { label: "Personal", value: "Personal" },
  { label: "Work", value: "Work" },
  { label: "Alternate", value: "Alternate" },
];
const AddressTypeOptions = [
  { label: "Address Type", disabled: true, value: "" },
  { label: "Personal", value: "Personal" },
  { label: "Work", value: "Work" },
  { label: "Alternate", value: "Alternate" },
];
const PhoneTypeOptions = [
  { label: "Phone Type", disabled: true, value: "" },
  { label: "Personal", value: "Personal" },
  { label: "Work", value: "Work" },
  { label: "Alternate", value: "Alternate" },
];

//flag to check if the component is mounted to display the page path
let isMounted = false;

const CreateAddressBook = ({
  onFormDataChange,
  toEdit,
  breadcrumbItems,
  setBreadcrumbItems,
  editDataID
}: any) => {

  console.log(toEdit)
  //Set the data empty:initial toEdit:on edit click
  const [addressbook, setaddressbook] = useState<addressBook>(
    toEdit ? toEdit : data
  );

  //Breadcrumbs
  useEffect(() => {
    if (!isMounted) {
      const newBreadcrumbs = [
        ...breadcrumbItems,
        { text: " / Create", url: "/" },
      ];
      setBreadcrumbItems(newBreadcrumbs);
    }
  }, [isMounted]);


  //to iterate over the input field index
  const [indexOfAddress, setIndexAddress] = useState(0);
  const [indexOfEmail, setIndexEmail] = useState(0);
  const [indexOfPhone, setIndexPhone] = useState(0);

  //State to set the selected types
  const [selectedEmailType, setSelectedEmailType] = useState([]);
  const [selectedAddressType, setSelectedAddressType] = useState([]);
  const [selectedPhoneType, setSelectedPhoneType] = useState([]);

  //Regular expression
  const emailRegex = /^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+.[a-zA-Z]$/;
  const nameRegex = /^([a-zA-Z]{1,29})+$/;
  const numberRegex = /^(\+?\d{1,2}[ -]?)?\d{10}$/;

  //Setting warning message
  const [warn,setWarn] = useState ({email:[""],phone:[""],name:"",lastname:""})
  const [dynamicAddWarn,setDynamicAddWarn] = useState ({email:"",phone:"",address:""})

  //Function + button
  const handleClickAddress = (event: any) => {
    event.preventDefault()
    const line1Value = addressbook.address[indexOfAddress].line1
    if (line1Value === "" || line1Value===undefined) {
      setDynamicAddWarn(prevState => ({...prevState, address: "Please complete the field before adding another address"}));
      } 
    else if (addressbook.address.length >= 3) {
        setDynamicAddWarn(prevState => ({...prevState, address: "A maximum of only 3 addresses can be entered"}));
    } else {
      setDynamicAddWarn(prevState => ({...prevState, address: ""}));
      const newAddress = { line1: "", line2: "" ,city: "",
      state: "",
      country: "",
      zipcode: "",
      addresstype:""};
      const addressArray = [...addressbook.address, newAddress];
      setaddressbook({ ...addressbook, address: addressArray });
      setIndexAddress(indexOfAddress + 1);
    }
  };

  const handleClickEmail = (event: any) => {
    event.preventDefault();
    const emailValue = addressbook.email[indexOfEmail].email
    if (emailValue === "" || emailValue===undefined) {
      setDynamicAddWarn(prevState => ({...prevState, email: "Please complete the field before adding another email address"}));
    } else if (addressbook.email.length >= 3) {
      setDynamicAddWarn(prevState => ({...prevState, email: "A maximum of only 3 email addresses can be entered"}));
    } else {
      setDynamicAddWarn(prevState => ({...prevState, email: ""}));
      const newEmail = { email: "", emailtype: "" };
      const emailArray = [...addressbook.email, newEmail];
      setaddressbook({ ...addressbook, email: emailArray });
      setIndexEmail(indexOfEmail + 1);
    }
  };

  function handleClickPhone(event: any) {
    event.preventDefault();
    const phoneValue = addressbook.phone[indexOfPhone].phone
    if (phoneValue === "" || phoneValue===undefined) {
      setDynamicAddWarn(prevState => ({...prevState, phone: "Please complete the field before adding another phone number"}));}
    
     else if (addressbook.phone.length >= 3) {
      setDynamicAddWarn(prevState => ({...prevState, phone: "A maximum of only 3 phone numbers can be entered"}));}
 
    else {
      setDynamicAddWarn(prevState => ({...prevState, phone: ""}));
      const newPhone = { phone: "", phonetype: "" };
      const phoneArray = [...addressbook.phone, newPhone];
      setaddressbook({ ...addressbook, phone: phoneArray });
      setIndexPhone(indexOfPhone + 1);
    }
  }

  //setting the value in their particular indexes on change (address,email,phone number) and validating email and phone number 
  const handleInputChange1 = (index: any, event: any) => {
    const { name, value } = event.target;
    const address :any = [...addressbook.address];
    address[index][name] = value;
    setaddressbook({ ...addressbook, address });
    const selectedTypes: any = { ...selectedAddressType };
    selectedTypes[index] = value;
    setSelectedAddressType(selectedTypes);
  };

  const handleInputChange2 = (index: any, event: any) => {
    const { name, value } = event.target;
    const email :any = [...addressbook.email];
    email[index][name] = value;
    setaddressbook({ ...addressbook, email });
    if(emailRegex.test(addressbook.email[index].email)){
      setWarn(prevState => ({...prevState, email: [""]}));
    }
    else{
      setWarn(prevState => {
        const updatedWarn = {...prevState};
        updatedWarn.email[index] = "Please enter a valid Email id";
        return updatedWarn;
      });
    }
      const selectedTypes: any = { ...selectedEmailType };
      selectedTypes[index] = value;
      setSelectedEmailType(selectedTypes);
  };

  const handleInputChange3 = (index: any, event: any) => {
    const { name, value } = event.target;
    const phone :any = [...addressbook.phone];
    phone[index][name] = value;
    setaddressbook({ ...addressbook, phone });
    if(numberRegex.test(addressbook.phone[index].phone)){
      setWarn(prevState => ({...prevState, phone: [""]}));
    }
    else{
      setWarn(prevState => {
        const updatedWarn = {...prevState};
        updatedWarn.phone[index] = "Please enter a valid Phone number";
        return updatedWarn;
      });
    }
    const selectedTypes: any = { ...selectedPhoneType };
    selectedTypes[index] = value;
    setSelectedPhoneType(selectedTypes);
  };

  //setting the value of firstname and lastname and validating them
  const handleInputChange = (event: any) => {
    const {name,value} = event.target
    setaddressbook({ ...addressbook, [name]: value });
    if(nameRegex.test(addressbook.name)){
      setWarn(prevState => ({...prevState, name: ""}));
    }
    else{
      setWarn(prevState => ({...prevState, name: "Please enter a valid Name"}));
    }
  };
  
  //Discarding the unwanted field
  const handleDiscardAddress = (indexToRemove: number, event: any) => {
    event.preventDefault();
    const address: any = [...addressbook.address];
    if (address.length > 1) {
      address.splice(indexToRemove, 1);
      setaddressbook({ ...addressbook, address });
      setIndexAddress(indexOfAddress - 1);
    } else {
      setDynamicAddWarn(prevState => ({...prevState, address: "Atleast 1 address is required"}));
    }
  };

  const handleDiscardEmail = (indexToRemove: number, event: any) => {
    event.preventDefault();
    const email: any = [...addressbook.email];
    if (email.length > 1) {
      email.splice(indexToRemove, 1);
      setaddressbook({ ...addressbook, email });
      setIndexEmail(indexOfAddress - 1);
    } else {
      setDynamicAddWarn(prevState => ({...prevState, email: "Atleast 1 email address is required"}));
    }
  };

  const handleDiscardPhone = (indexToRemove: number, event: any) => {
    event.preventDefault();
    const phone: any = [...addressbook.phone];
    if (phone.length > 1) {
      phone.splice(indexToRemove, 1);
      setaddressbook({ ...addressbook, phone });
      setIndexPhone(indexOfAddress - 1);
    } else {
      setDynamicAddWarn(prevState => ({...prevState, phone: "Atleast 1 phone number is required"}));
    }
  };

  //Cancel button
  const handleCancel = (e:any) => {
    e.preventDefault();
    setaddressbook({
      name: "",
      lastname: "",
      email: [{
        email: "",
        emailtype: ""
      }],
      address: [{
        line1: "",
        line2: "",
        city: "",
        state: "",
        country: "",
        zipcode: "",
        addresstype:""
      }],
      phone: [{
        phone: "",
        phonetype : ""
      }]
    });
    
  };

 //Check if all the fields are filled and set warning
  const checkName = () => {
    if (!addressbook?.name) {
      formErrors.name = "Name is required";
    }
    if (!addressbook?.lastname) {
      formErrors.lastname = "Last Name is required";
    }
    else{
      return true;
    }
  }

  const checkPhone = () => {
    if (!addressbook?.phone || addressbook.phone.some(p => !p.phone || !p.phonetype)) {
      const phoneErrors = addressbook?.phone?.map((p, index) => {
        let error={phone:"",phonetype:""}
        if (!p.phone) {
          error.phone = `Phone number is required` ;
        }
        if(!p.phonetype){
          error.phonetype = `Phone number type is required`
        }
        return {...error, key: `phoneError-${index}` };
      }).filter(Boolean);
      if (phoneErrors.length > 0) {
        setWarn({ email:[""], phone: [""], name: "" ,lastname:"" });
        formErrors.phone = phoneErrors;
      }
    }
  }

  const checkEmail = () => {
    if (!addressbook?.email || addressbook.email.some(e => !e.email || !e.emailtype)) {
      const emailErrors = addressbook?.email?.map((e, index) => {
        let error={email:"",emailtype:""}
        if (!e.email) {
          error.email = `Email address is required` ;
        }
        if(!e.emailtype){
          error.emailtype = `Email type is required`
        }
        return {...error,  key: `emailError-${index}` };
      }).filter(Boolean);
      if (emailErrors.length > 0) {
        setWarn({ email: [""], phone: [""], name: "" ,lastname:""});
        formErrors.email = emailErrors;
      }
    }
  }

  const checkAddress = (): void => {
    const addresses = addressbook?.address;
    if (!addresses) {
      return;
    }
    const errors = addresses.map((address, index) => {
      const error: Record<string, string> = {};
      if (!address.line1) {
        error.line1 = `Line 1 is required`;
      }
      if (!address.line2) {
        error.line2 = `Line 2 is required`;
      }
      if (!address.city) {
        error.city = `City is required`;
      }
      if (!address.state) {
        error.state = `State is required`;
      }
      if (!address.zipcode) {
        error.zipcode = `Zipcode is required`;
      }
      if (!address.country) {
        error.country = `Country is required`;
      }
      if (!address.addresstype) {
        error.addresstype = `Address type is required`;
      }
      return Object.keys(error).length === 0 ? null : { ...error, key: `addressError-${index}` };
    }).filter(Boolean);
    if (errors.length > 0) {
      formErrors.address = errors;
    }
  };
  

  //Check if the warn object is empty as it is set if the entered credentials are not valid (name,email,phonenumber)
  const isWarnEmpty = () => {
      return Object.values(warn).every((value) => {
        if (Array.isArray(value)) {
          return value.length === 0 || value.every((item) => item === "");
        }
        return value === "";
      });
    };

  //Submit - form
  const formErrors: Partial<any> = {};
  const [errors, setErrors] = useState<Record<string, any>>({});
  const handleAddInfoSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    checkName();
    checkPhone();
    checkEmail();
    checkAddress();
    const isValid = isWarnEmpty();

    if (Object.keys(formErrors).length > 0 || !isValid ) {
      setErrors(formErrors);
    } else {
      onFormDataChange(addressbook);
    }
  };
 
  return (
    <SubmitForm onSubmit={handleAddInfoSubmit}>  
      <ToastContainer />
      <FullContainerCreate>
        <PageContent>
          <MainContent>
            <MainContainerCreate>
              <DetailsCreate>
                <PageContent>
                  <ContainerWarn>
                   
                    <InputName
                      name="name"
                      value={addressbook.name}
                      placeholder="First Name"
                      onChange={handleInputChange}
                      className= {errors.name || warn.name ? "errorDiv" : ""}
                    />
                    {!errors.name && warn.name && <ValidateWarn>{warn.name}</ValidateWarn>}
                    {errors.name && <><ValidateWarn>{errors.name}</ValidateWarn></>}
                  </ContainerWarn>
                  <ContainerWarn>
                  
                    <InputLastName
                      name="lastname"
                      placeholder="Last Name"
                      value={addressbook.lastname}
                      onChange={handleInputChange}
                      className= {errors.lastname || warn.lastname ? "errorDiv" : ""}
                    />
                    {!errors.name && warn.lastname && <ValidateWarn>{warn.lastname}</ValidateWarn>}
                    {errors.lastname && <><ValidateWarn>{errors.lastname}</ValidateWarn></>}
                  </ContainerWarn>
                </PageContent>
              </DetailsCreate>

              <DetailsCreate>
                {/* address */}
                <HeadingPlusButton>
                  <Heading3>Address</Heading3>
                  <AddPlusButton
                    className="addbtn"
                    onClick={(event) => handleClickAddress(event)}
                  >
                    +
                  </AddPlusButton>
                </HeadingPlusButton>
                {dynamicAddWarn.address && <ValidateWarn>{dynamicAddWarn.address}</ValidateWarn>}

                {addressbook.address.map((address: any, index: any) => (
                  <GetDetails1 key={index}>
                    <DetailsContainer>
                      <ContainerWarn>
                        <InputField
                          name="line1"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="Line1"
                          value={address.line1}
                          className= {errors.address && errors.address[index] && errors.address[index].line1 ? "errorDiv" : ""}
                        ></InputField>
                        {errors.address && errors.address[index] && <><ValidateWarn>{errors.address[index].line1}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <InputField
                          name="line2"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="Line2"
                          value={address.line2}
                          className= {errors.address && errors.address[index] && errors.address[index].line2 ? "errorDiv" : ""}
                        ></InputField>
                        {errors.address&& errors.address[index] && <><ValidateWarn>{errors.address[index].line2}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <InputField
                          name="city"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="City"
                          value={address.city}
                          className= {errors.address && errors.address[index] && errors.address[index].city ? "errorDiv" : ""}
                        />
                         {errors.address&& errors.address[index] && <><ValidateWarn>{errors.address[index].city}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <InputField
                          name="state"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="State"
                          value={address.state}
                          className= {errors.address && errors.address[index] && errors.address[index].state ? "errorDiv" : ""}
                        />
                         {errors.address&& errors.address[index] && <><ValidateWarn>{errors.address[index].state}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <InputField
                          name="country"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="Country"
                          value={address.country}
                          className= {errors.address && errors.address[index] && errors.address[index].country ? "errorDiv" : ""}
                        />
                         {errors.address&& errors.address[index] && <><ValidateWarn>{errors.address[index].country}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <InputField
                          name="zipcode"
                          onChange={(event: any) =>
                            handleInputChange1(index, event)
                          }
                          placeholder="Zipcode"
                          value={address.zipcode}
                          className= {errors.address && errors.address[index] && errors.address[index].zipcode ? "errorDiv" : ""}
                        />
                         {errors.address&& errors.address[index] && <><ValidateWarn>{errors.address[index].zipcode}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <Select
                          key={`selectAddress-${index}`}
                          name="addresstype"
                          onChange={(event: any) => {
                            handleInputChange1(index, event);
                          }}
                          options={AddressTypeOptions}
                          value={address.addresstype}
                          className= {errors.address && errors.address[index] && errors.address[index].addresstype ? "errorDiv" : ""}
                        />
                        {errors.address && errors.address[index] && <ValidateWarn>{errors.address[index].addresstype}</ValidateWarn>}
                      </ContainerWarn>
                    </DetailsContainer>

                    <DiscardContainer>
                      <CreatePageButton
                        border="none"
                        color="transparent"
                        onClick={(event) => handleDiscardAddress(index, event)}
                        width="50px"
                      >
                        <DiscardIcon />
                      </CreatePageButton>
                    </DiscardContainer>
                  </GetDetails1>
                ))}
              </DetailsCreate>

              {/* email */}
              <DetailsCreate>
                <HeadingPlusButton>
                  <Heading3>Email</Heading3>
                  <AddPlusButton className="addbtn" onClick={handleClickEmail}>
                    +
                  </AddPlusButton>
                </HeadingPlusButton>
                {dynamicAddWarn.email && <ValidateWarn>{dynamicAddWarn.email}</ValidateWarn>}
                {addressbook.email.map((email: any, index: any) => (
                  <GetDetails1
                    key={index} >
                    <DetailsContainer>
                      <ContainerWarn>
                        <InputField
                          id="email"
                          name="email"
                          onChange={(event: any) => {
                            handleInputChange2(index, event);
                          }}
                          placeholder="Email Address"
                          value={email.email}
                          className= {errors.email&& errors.email[index] &&errors.email[index].email ? "errorDiv" : ""}
                        ></InputField>
                        {!errors.email && warn.email && warn.email[index]&&<ValidateWarn>{warn.email[index]}</ValidateWarn>}
                        {errors.email&& errors.email[index] &&errors.email[index].email && <><ValidateWarn>{errors.email[index].email}</ValidateWarn></>}
                      </ContainerWarn>
                      <ContainerWarn>
                        <Select
                          key={`selectEmail-${index}`}
                          name="emailtype"
                          onChange={(event: any) => {
                            handleInputChange2(index, event);
                          }}
                          options={EmailTypeOptions}
                          value={email.emailtype}
                          className= {errors.email&& errors.email[index] &&errors.email[index].emailtype ? "errorDiv" : ""}
                        />
                        {errors.email&& errors.email[index] &&errors.email[index].emailtype && <><ValidateWarn>{errors.email[index].emailtype}</ValidateWarn></>}
                      </ContainerWarn>
                    </DetailsContainer>
                    <DiscardContainer>
                      <CreatePageButton
                        border="none"
                        color="transparent"
                        onClick={(event) => handleDiscardEmail(index, event)}
                        width="50px"
                      >
                        <DiscardIcon />
                      </CreatePageButton>
                    </DiscardContainer>
                  </GetDetails1>
                ))}
              </DetailsCreate>

              {/* phone number */}
              <DetailsCreate>
                <HeadingPlusButton>
                  <Heading3>Phone number</Heading3>
                  <AddPlusButton className="addbtn" onClick={handleClickPhone}>
                    +
                  </AddPlusButton>
                </HeadingPlusButton>
                {dynamicAddWarn.phone && <ValidateWarn>{dynamicAddWarn.phone}</ValidateWarn>}
                {addressbook.phone.map((phone: any, index: any) => (
                  <GetDetails1 key={index}>
                    <DetailsContainer>
                      <ContainerWarn>
                        <InputField
                          name="phone"
                          onChange={(event: any) =>
                            handleInputChange3(index, event)
                          }
                          placeholder="Phone Number"
                          value={phone.phone}
                          className= {errors.phone&& errors.phone[index] && errors.phone[index].phone ?  "errorDiv" : ""}
                        />
                         {!errors.phone && warn.phone && warn.phone[index] && <ValidateWarn>{warn.phone[index]}</ValidateWarn>}
                          {errors.phone&& errors.phone[index] && errors.phone[index].phone ? <><ValidateWarn>{errors.phone[index].phone}</ValidateWarn></> :""}
                      </ContainerWarn>
                      <ContainerWarn>
                        <Select
                          key={`selectPhone-${index}`}
                          name="phonetype"
                          onChange={(event: any) => {
                            handleInputChange3(index, event);
                          }}
                          options={PhoneTypeOptions}
                          value={phone.phonetype}
                          className= {errors.phone&& errors.phone[index] && errors.phone[index].phonetype ?  "errorDiv" : ""}
                        />
                        {errors.phone&& errors.phone[index] &&errors.phone[index].phonetype && <><ValidateWarn>{errors.phone[index].phonetype}</ValidateWarn></>}
                      </ContainerWarn>
                    </DetailsContainer>
                    <DiscardContainer>
                      {" "}
                      <CreatePageButton
                        border="none"
                        color="transparent"
                        onClick={(event) => handleDiscardPhone(index, event)}
                        width="50px"
                      >
                        <DiscardIcon />
                      </CreatePageButton>
                    </DiscardContainer>
                  </GetDetails1>
                ))}
              </DetailsCreate>

              {/* action buttons */}
              <TitleContainer>
                {editDataID == null ? <CreatePageButton color="#252d38" type="submit">
                  Save
                  </CreatePageButton> : <CreatePageButton color="#252d38" type="submit">
                  Update
                  </CreatePageButton>}
                
                <CreatePageButton
                  color="#c96624"
                  onClick={(e) => handleCancel(e)}
                >
                  Cancel
                </CreatePageButton>
              </TitleContainer>
            </MainContainerCreate>
          </MainContent>
        </PageContent>
      </FullContainerCreate>
    </SubmitForm>
  );
};

export default CreateAddressBook;
