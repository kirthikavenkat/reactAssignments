import { Link } from "react-router-dom";
import styled from "styled-components";

export const InputText = styled.input`
  height: 35px;
  width: 100%;
  border: 1px solid gray;
  border-radius: 2px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px 10px 20px 20px;
  @media (max-width: 713px) {
    width: 85%;
  }
`;

export const SelectTag = styled.select`
  height: 35px;
  width: 82%;
  border: 1px solid gray;
  border-radius: 5px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px;

  background-color: #eeeeee90;
  @media (max-width: 713px) {
    width: 85%;
  }
`;
export const CreatePageButton = styled.button.attrs(
  (props: { color: string; border: string; width: string }) => props
)`
  width: 100px;
  width: ${(props) => props.width};
  height: 35px;
  border: 1px solid rgba(0, 0, 0, 0.24);
  border-radius: 5px;
  color: white;
  font-size: large;
  margin: 20px;
  background-color: ${(props) => props.color};
  border: ${(props) => props.border};
  cursor: pointer;
`;
export const AddressBookImage = styled.img`
  width: 35px;
  height: 35px;
  padding-left: 20px;
`;
export const TitleContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
export const FullContainerCreate = styled.div`
  width: 100%;
  align-items: center;
  top: 55%;
  justify-content: center;
  position: relative;
  @media (max-width: 768px) {
    width: 90%;
    margin-left: 5%;
    top: 35%;
  }
  @media (max-width: 425px) {
    width: 100%;
    margin-left: 5%;
    margin-top: 20%;
  }
`;
export const Image = styled.img`
  width: 20px;
  height: 20px;
  position: fixed;
  right: 190px;

  @media (max-width: 425px) {
    right: 37%;
  }
  @media (max-width: 375px) {
    right: 37%;
  }
  @media (max-width: 320px) {
    right: 44%;
    top: 85px;
  }
`;
export const SubmitForm = styled.form`
  @media (max-width: 425px) {
  }
  margin-top: 15%;
`;
export const Header = styled.div`
  display: flex;
  flex-direction: row;
  height: 12%;
  position: fixed;
  top: 0px;
  border: 2px solid black;
  box-shadow: 0px 0px 2px black;
  width: 100%;
  align-items: center;
  background-color: white;
  z-index: 4;

  @media (max-width: 350px) {
    height: 20%;
  }
`;
export const PageContent = styled.div`
  display: flex;
  flex-direction: row;
  width: full;
  @media (max-width: 425px) {
    flex-direction: column;
  }
`;
export const SideBar = styled.div`
  width: 150px;
  height: 100vh;
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: fixed;
  border: 2px solid black;
  background-color: white;
  z-index: 3;
  top: 12.5%;
  @media (max-width: 600px) {
    width: 100%;
    height: 80px;
    flex-direction: row;
    top: 10%;
  }
  @media (max-width: 425px) {
    top: 12.5%;
  }
  @media (max-width: 350px) {
    top: 20%;
  }
`;
export const MainContent = styled.div`
  z-index: 1;
  width: 91%;
  margin-top: 40px;
  @media (max-width: 768px) {
    width: 85%;
    margin-left: 20%;
    margin-top: 100px;
  }
  @media (max-width: 425px) {
    width: 95%;
    margin-left: 0px;
    margin-top: 140px;
  }
`;
export const PagePathStyle = styled.div`
  height: 25px;
  width: 88%;
  margin: 10px 10px 10px 20px;
  position: relative;
  top: 130px;
  z-index: 20;
  display: flex;
  padding: 15px;
  align-items: center;
  flex-direction: row;
  gap: 8px;
  background-color: #f5f5f5;
  border-radius: 5px;
  @media (max-width: 768px) {
    width: 75%;
    margin-left: 22%;
  }
  @media (max-width: 425px) {
    margin-top: 100px;
    width: 75%;
    margin-left: 15px;
  }
  @media (max-width: 375px) {
    margin-top: 60px;
    width: 75%;
    margin-left: 15px;
  }
`;
export const MainContainerCreate = styled.div`
  width: 100%;
  height: fit-content;
  box-shadow: 0px 0px 2px black;
  padding-bottom: 10px;
  background-color: white;
  margin-left: 2%;
  margin-bottom: 20px;
  @media (max-width: 425px) {
    margin-left: 3px;
  }
`;
export const DetailsCreate = styled.div`
  box-shadow: 0px 0px 2px black;
  padding-bottom: 20px;
  padding-left: 20px;
  @media (max-width: 425px) {
    padding-left: 0px;
  }
`;

export const HeadingPlusButton = styled.div`
  display: flex;
`;
export const GetDetails = styled.div`

`;

export const GetDetails1 = styled.div`
  width: 95%;
  display: grid;
  grid-template-columns: 3.8fr 0.2fr;
  @media (max-width: 425px) {
    grid-template-columns: 1fr;
  }
`;
export const DiscardContainer = styled.div`
  justify-content: center;
  margin: auto;
`;
export const DetailsContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  @media (max-width: 425px) {
    grid-template-columns: 1fr;
  }
`;
export const InputName = styled.input.attrs(
  (props: { className: string }) => props
)`
  height: 35px;
  width: 80%;
  border: 1px solid gray;
  border-radius: 2px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px;
  border: ${(props) => (props.className === "errorDiv" ? "1px solid red" : "")};
  @media (max-width: 713px) {
    width: 85%;
  }
`;
export const InputLastName = styled.input.attrs(
  (props: { className: string }) => props
)`
  height: 35px;
  width: 80%;
  border: 1px solid gray;
  border-radius: 2px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px;
  border: ${(props) => (props.className === "errorDiv" ? "1px solid red" : "")};
  @media (max-width: 713px) {
    width: 85%;
  }
`;

export const ContainerWarn = styled.div`
  display: flex;
  flex-direction: column;
  width: 80%;
`;
export const EmailWarn = styled.div`
  display: flex;
  width: 100%;
`;
export const ValidateWarn = styled.div`
  width: 100%;
  gap: 65px;
  padding-left: 18px;
  font-size: small;
  color: red;
  margin-top: -15px;
`;
export const DialogBox = styled.div`
  display: none;
  width: 33%;
  height: 10%;
  border: 1px solid gray;
  background-color: gray;
  position: relative;
  left: 40%;
  top: 65%;
  z-index: 100;
  @media (max-width: 500px) {
    top: 100%;
  }
`;
export const AddPlusButton = styled.button`
  background: none;
  border: none;
  font-size: 30px;
  cursor: pointer;
  margin-top: 3px;
`;
export const Heading2 = styled.h2`
  position: fixed;
  color: black;
  right: 25px;
  @media (max-width: 485px) {
    font-size: large;
  }
  @media (max-width: 320px) {
    font-size: medium;
    top: 70px;
  }
`;
export const Heading1 = styled.h1`
  position: relative;
  left: 2%;
  color: black;
  @media (max-width: 485px) {
    height: full;
    font-size: x-large;
  }
  @media (max-width: 350px) {
    font-size: large;
  }
`;
export const Heading3 = styled.h3`
  margin-left: 15px;
`;
export const AnchorTag = styled.a`
  color: blue;
  padding-left: 12px;
  text-decoration: none;
  justify-content: center;
`;
export const LinkRoute = styled(Link)`
  color: blue;
  padding-left: 20px;
  text-decoration: none;
  height: 50px;
  justify-content: center;
  padding-top: 18px;
  :hover {
    text-decoration: underline;
  }
`;
