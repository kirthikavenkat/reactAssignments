import styled from "styled-components";
export const ViewContainer = styled.div`
  margin-top: 100px;
  margin-left: 20px;
  background-color: white;
  width: 90%;
  padding: 20px 0 40px 20px;
`;
export const Heading4 = styled.h4`
  font-weight: normal;
`;
export const Heading3 = styled.h2`
  font-size: large;
`;
export const Heading2 = styled.h2`
  font-size: larger;
`;
