import { useEffect } from "react";
import {
  Heading2,
  Heading3,
  Heading4,
  ViewContainer,
} from "./ViewAddress.style";
let isMounted = false;

const ViewAddressBook = ({
  state,
  setView,
  breadcrumbItems,
  setBreadcrumbItems,
}: any) => {
  useEffect(() => {
    if (!isMounted) {
      const newBreadcrumbs = [
        ...breadcrumbItems,
        { text: ` / ${state.name} `, url: "/" },
      ];

      setBreadcrumbItems(newBreadcrumbs);
      isMounted = true;
    }
  }, [isMounted]);
  return (
    <ViewContainer>
      <>
        <div>
          <h1>
            {state.name} {state.lastname}
          </h1>
          <div>
            <Heading2>Addresses</Heading2>
            <hr></hr>
            <div>
              {state.address.map((addressitem: any, addressindex: number) => (
                <Heading4 key={addressindex}>
                  <Heading3>{addressitem.addresstype}</Heading3>
                  {addressitem.line1}
                  {","}
                  {addressitem.line2}
                  {","}
                  {addressitem.city}
                  {","}
                  {addressitem.state}
                  {","}
                  {addressitem.country}
                  {","}
                  {addressitem.zipcode}
                </Heading4>
              ))}
            </div>
            <Heading2>Phone Numbers</Heading2>
            <hr></hr>
            {state.phone.map((phoneitem: any, phoneindex: number) => (
              <div key={phoneindex}>
                <Heading3>{phoneitem.phonetype}</Heading3>

                <Heading4>{phoneitem.phone}</Heading4>
              </div>
            ))}
          </div>
          <Heading2>Email Addresses</Heading2>
          <hr></hr>
          <div>
            {state.email.map((emailitem: any, emailindex: number) => (
              <div key={emailindex}>
                <Heading3>{emailitem.emailtype}</Heading3>

                <Heading4>{emailitem.email}</Heading4>
              </div>
            ))}
          </div>
        </div>
        <button onClick={()=>setView(false)}>Go Back</button>
      </>
    </ViewContainer>
  );
};

export default ViewAddressBook;
