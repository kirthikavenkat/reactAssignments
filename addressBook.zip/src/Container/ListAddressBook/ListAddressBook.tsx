import React, { useState, useEffect } from "react";
import SearchIcon from "../../Assets/SearchIcon.svg";
import NumberCarousel from "../../Components/Pagination/Pagination";
import { addressBook } from "../CreateAddressBook/CreateAddressBook";
import ViewAddressBook from "../ViewAddress/ViewAddress";
import {
  ActionButtons,
  DialogBox,
  DeleteDialogButtons,
  FullContainerCreate,
  Image,
  InputSearch,
  NoDataContainer,
  TableBody,
  TableContainer,
  TableData,
  TableHead,
  TableHeader,
  TableList,
  TableRow,
} from "./ListAddressBook.style";
import { toast } from "react-toastify";
//flag to check if the component is mounted to display the page path
let isMounted = false;

const ListAddress = ({
  formData,
  toastMessage,
  setToastMessage,
  item,
  setEditDataID,
  setEditValue,
  setShowCreateAddress,
  setShowListAddress,
  setformData,
  breadcrumbItems,
  setBreadcrumbItems,
}: any) => {
  //View data
  const [selectedData, viewSelectedData] = useState(item);
  const [viewAddress, setView] = useState(false);

  //Show and hide delete dialog box
  const [showDelete, setShowDelete] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState();

  //Success toast
  useEffect(() => {
    if (toastMessage) {
      toast.success(toastMessage, { position: toast.POSITION.BOTTOM_RIGHT });
      setToastMessage("");
    }
  }, [toastMessage, setToastMessage]);

  //On click of name in the table
  const handleViewClick = (data: any) => {
    viewSelectedData(data);
    setView(true);
  };

  //Updating the state to display the path on component render
  useEffect(() => {
    if (!isMounted) {
      const newBreadcrumbs = [
        ...breadcrumbItems,
        { text: "Address Book ", url: "/" },
      ];
      setBreadcrumbItems(newBreadcrumbs);
      isMounted = true;
    }
    const hasCreateBreadcrumb = breadcrumbItems.find(
      (item: any) => item.text === " / Create" 
    );
    if (hasCreateBreadcrumb) {
      const filteredBreadcrumbs = breadcrumbItems.filter(
        (breadcrumb: any) => breadcrumb.text !== " / Create"
      );
      setBreadcrumbItems(filteredBreadcrumbs);
    }
  }, []);

  //On click of edit button
  const handleEdit = (item: addressBook, index: any) => {
    setEditValue(item);
    setEditDataID(index);
    setShowCreateAddress(true);
    setShowListAddress(false);
  };

  //Search
  const [searchQuery, setSearchQuery] = useState("");
  const items = formData;
  const filteredData = items.filter((item: any) =>
    item.name.includes(searchQuery)
  );

  //Logic to delete the item
  const handleDelete = (index: any, event: any) => {
    event.preventDefault();
    setShowDelete(true);
    setDeleteIndex(index);
  };
  const handleOkClick = () => {
    const items = formData;
    if (items.length > 0) {
      const Index = deleteIndex;
      setformData(items.filter((item: any, index: any) => index !== Index));
    }
    setShowDelete(false);
  };

  const handleCancelClick = () => {
    setShowDelete(false);
  };

  //Pagination
  const [currentPage, setCurrentPage] = useState(1);
  let data = searchQuery.length === 0 ? formData : filteredData;
  const numPages = Math.ceil(formData.length / 5);
  const startIdx = (currentPage - 1) * 5;
  const endIdx = startIdx + 5;
  const displayedData = data.slice(startIdx, endIdx);
  const handlePageChange = (page: any) => {
    setCurrentPage(page);
  };

  return (
    <React.Fragment>
      {viewAddress ? (
          <ViewAddressBook
            state={selectedData}
            setView={setView}
            breadcrumbItems={breadcrumbItems}
            setBreadcrumbItems={setBreadcrumbItems}
          />
      ) : (
            <FullContainerCreate>
              <Image src={SearchIcon}></Image>
              <InputSearch
                id="search"
                name="search"
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..."
                style={{ backgroundColor: "white",fontSize:"medium" }}
              ></InputSearch>
              <TableContainer>
                <TableList>
                  <TableHead>
                    <TableRow>
                      <TableHeader>Name</TableHeader>
                      <TableHeader>Phone Number</TableHeader>
                      <TableHeader>Email address</TableHeader>
                      <TableHeader>Address</TableHeader>
                      <TableHeader>Action</TableHeader>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <>
                      {displayedData.map((item: any, index: number) => (
                        <>
                          <TableRow key={index}>
                            <TableData
                              onClick={() => handleViewClick(item)}
                              style={{ cursor: "pointer" }}
                            >
                              {item.name}
                              {item.lastname}
                            </TableData>

                            <TableData>
                              {item.phone.map(
                                (phoneitem: any, phoneindex: number) => (
                                  <div key={phoneindex}>{phoneitem.phone}</div>
                                )
                              )}
                            </TableData>
                            <TableData>
                              {item.email.map(
                                (emailitem: any, emailindex: number) => (
                                  <div key={emailindex}>{emailitem.email}</div>
                                )
                              )}
                            </TableData>
                            <TableData>
                              {item.address.map(
                                (addressitem: any, addressindex: number) => (
                                  <div key={addressindex}>
                                    {addressitem.line1}
                                    {","}
                                    {addressitem.line2}
                                    {","}
                                    {addressitem.city}
                                    {","}
                                    {addressitem.state}
                                    {","}
                                    {addressitem.country}
                                    {","}
                                    {addressitem.zipcode}
                                    <br></br>
                                  </div>
                                )
                              )}
                            </TableData>
                            <TableData>
                              {
                                <div style={{display: "flex"}}>
                                  <ActionButtons
                                    onClick={() => handleEdit(item, index)}
                                  >
                                    Edit
                                  </ActionButtons>
                                  <ActionButtons
                                    onClick={(event) =>
                                      handleDelete(index, event)
                                    }
                                  >
                                    Delete
                                  </ActionButtons>
                                </div>
                              }
                            </TableData>
                          </TableRow>
                        </>
                      ))}
                    </>
                  </TableBody>
                </TableList>
              </TableContainer>

              {formData.length >= 5 || searchQuery.length!==0 ? filteredData.length > 5 ?(
                <NumberCarousel
                  numPages={numPages}
                  currentPage={currentPage}
                  onPageChange={handlePageChange}
                />
              ):"":""}
              {formData.length < 1 && searchQuery.length === 0 &&(
                <NoDataContainer>No data</NoDataContainer>
              )}
              {searchQuery.length !== 0 && filteredData.length === 0 && (
                <NoDataContainer>No data</NoDataContainer>
              )}
            </FullContainerCreate>
      )}

      {showDelete && (
        <DialogBox className="dialogBox1">
          <div>
            Are you sure you want to delete this item?
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "auto",
              }}
            >
              <DeleteDialogButtons
                id="okBtn"
                backgroundColor="#b32424"
                color="white"
                onClick={handleOkClick}
              >
                Ok
              </DeleteDialogButtons>
              <DeleteDialogButtons
                id="cancelBtn"
                margin="27px"
                backgroundColor="#94bac989"
                color="black"
                onClick={handleCancelClick}
              >
                Cancel
              </DeleteDialogButtons>
            </div>
          </div>
        </DialogBox>
      )}
    </React.Fragment>
  );
};
export default ListAddress;
