import styled, { keyframes } from "styled-components";

export const MainTable = styled.table``;

export const AnimatedDialog = keyframes`
  0% { top: 0%; left:40%; }
 100% { top: 20%; left: 40%;}
`;
export const FullContainerCreate = styled.div`
  width: 97%;
  align-items: center;
  justify-content: center;
  position: relative;
  top: 130px;
  margin-left: 3%;
  padding-bottom: 30px;
  @media (max-width: 900px) {
    width: 80%;
    top: 200px;
  }
  @media (max-width: 880px) {
    width: 80%;
    margin-left: 10%;
    top: 180px;
  }
  @media (max-width: 768px) {
    width: 80%;
    margin-left: 25%;
    top: 180px;
  }
  @media (max-width: 425px) {
    width: 100%;
    margin-left: 6%;
    top: 130px;
  }
  @media (max-width: 375px) {
    width: 100%;
    margin-left: 6%;
    top: 170px;
  }
  @media (max-width: 360px) {
    width: 100%;
    margin-left: 6%;
    top: 170px;
  }

`;
export const InputSearch = styled.input`
  height: 35px;
  width: 300px;
  border: 1px solid gray;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px 20px 20px -45px;
  padding-left: 50px;
  background-color: #eeeeee90;
  @media (max-width: 730px) {
    width: 60%;
  }
`;
export const PageContent = styled.div`
  display: flex;
  flex-direction: row;
  width: full;
`;

export const Image = styled.img`
  width: 30px;
  height: 30px;

  position: relative;
  top: 8px;
  @media (max-width: 425px) {
    margin-left: 10px;
  }
`;
export const ActionButtons = styled.button`
  width: 50px;
  height: 35px;
  border: 1px solid rgba(0, 0, 0, 0.24);
  border-radius: 5px;
  color: black;
  font-size: small;
  margin: 10px;
  cursor: pointer;
`;
export const TableList = styled.table`
  width: 90%;
  border-collapse: collapse;
  border: 1px solid gray;
`;
export const NoDataContainer = styled.div`
  display: flex;
  width: full;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
  font-size: 15px;
`;
export const TableContainer = styled.div`
  @media (max-width: 600px) {
    overflow-x: scroll;
  }

  width: 100%;
`;
export const TableHead = styled.thead`
  width: 40%;
`;
export const TableBody = styled.tbody`
  align-items: center;
  justify-content: center;
  text-align: center;
  margin-left: 20px;
  border: 1px solid gray;
`;
export const TableHeader = styled.th`
  border: 1px solid gray;
  background-color: #cccccc;
  color: black;
  height: 55px;
`;
export const TableRow = styled.tr`
  background-color: #33394126;
  border: 1px solid gray;
  :nth-of-type(odd) {
    background-color: white;
  }
  :nth-of-type(even) {
    background-color: #ececec;
  }
  :hover {
    background-color: white;
  }
`;
export const TableData = styled.td`
  border: 1px solid gray;
  height: 20px;
`;
export const DialogBox = styled.div`
  width: 280px;
  height: 80px;
  padding: 25px;
  border: 1px solid gray;
  background-color: #fffffff6;
  position: absolute;
  left: 40%;
  top: 20%;
  box-shadow: 3px 3px 3px 3px black;
  z-index: 40;
  border-radius: 25px;
  animation-name: ${AnimatedDialog};
  animation-duration: 0.1s;
  @media (max-width: 500px) {
    top: 40%;
  }
`;
export const DeleteDialogButtons = styled.div.attrs(
  (props: { color: string; margin: string; backgroundColor: string }) => props
)`
  width: 60px;
  height: 25px;
  border: 1px solid gray;
  cursor: pointer;
  text-align: center;
  border-radius: 4px;
  background-color: ${(props) => props.backgroundColor};
  color: ${(props) => props.color};
  margin-left: ${(props) => props.margin};
`;
