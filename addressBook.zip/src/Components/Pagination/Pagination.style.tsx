import styled from "styled-components";

export const MainContainerCarousel = styled.div`
  justify-content: space-between;
  width: 90%;
  display: flex;
`;
export const NumberButton = styled.div`
  position: relative;
  margin-top: 1rem;
  display: flex;
`;

export const PaginationPreviousIcon = styled.img.attrs(
  (props: { className: string }) => props
)`
  display: ${(props) => (props.className === "first" ? "none" : "")};
  cursor: pointer;
`;
export const PaginationNextIcon = styled.img.attrs(
  (props: { className: string }) => props
)`
  display: ${(props) => (props.className === "last" ? "none" : "")};
  cursor: pointer;
`;
export const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  white-space: nowrap;
  padding: 0.5rem 0;
`;
export const PaginationPreviousButton = styled.button.attrs(
  (props: { className: string }) => props
)`
  display: ${(props) => (props.className === "first" ? "none" : "")};
  background-color: white;
  border: none;
  cursor: pointer;
  font-size: larger;
  padding: 10px;
`;
export const PaginationNextButton = styled.button.attrs(
  (props: { className: string }) => props
)`
  display: ${(props) => (props.className === "last" ? "none" : "")};
  background-color: white;
  border: none;
  cursor: pointer;
  font-size: larger;
  padding: 10px;
`;
export const ButtonCarousel = styled.button.attrs(
  (props: { color: string; className: string }) => props
)`
  display: flex;
  width: 100%;
  background-color: #fff;
  color: black;
  padding: 0.3rem 0.5rem;
  border: 1px solid #ccc;
  /* border-top: 1px solid #ccc; */
  cursor: pointer;
  background-color: ${(props) =>
    props.className === "active" ? "gray" : "white"};
  @media screen and (max-width: 800px) {
    padding: 0.2rem 0.4rem;
  }
  @media screen and (max-width: 650px) {
    padding: 0.1rem 0.3rem;
  }
`;
