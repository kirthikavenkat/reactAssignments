import {
  MainContainerCarousel,
  NumberButton,
  PaginationPreviousButton,
  PaginationNextButton,
  PaginationPreviousIcon,
  PaginationNextIcon
} from "./Pagination.style";
import PreviousIcon from "../../Assets/PreviousIcon.svg";
import NextIcon from "../../Assets/NextIcon.svg";
const NumberCarousel = ({ numPages, currentPage, onPageChange }: any) => {
  const nextNumber = () => {
    onPageChange(numPages > currentPage  ? currentPage + 1 : currentPage);
  };

  const prevNumber = () => {
    onPageChange(currentPage === 1 ? 1 : currentPage - 1);
  };

  return (
    <MainContainerCarousel>
      <NumberButton>
        <PaginationPreviousIcon src={PreviousIcon} onClick={prevNumber} className={currentPage === 1 ? "first" : ""} />
        <PaginationPreviousButton className={currentPage === 1 ? "first" : ""} onClick={prevNumber}>
          Previous
        </PaginationPreviousButton>
      </NumberButton>
      <NumberButton>
        <PaginationNextButton className={currentPage === numPages ? "last" : ""} onClick={nextNumber}>
          Next
        </PaginationNextButton>
        <PaginationNextIcon src={NextIcon} onClick={nextNumber} className={currentPage === numPages ? "last" : ""} />
      </NumberButton>
    </MainContainerCarousel>
  );
};

export default NumberCarousel;
