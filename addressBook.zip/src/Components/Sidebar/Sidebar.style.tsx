import styled from "styled-components";
import { Link } from "react-router-dom";
export const LinkRoute = styled(Link)`
  color: blue;
  padding-left: 20px;
  text-decoration: none;
  height: 50px;
  justify-content: center;
  padding-top: 18px;
  :hover {
    text-decoration: underline;
  }
`;
export const SideBar = styled.div`
  width: 150px;
  height: 100vh;
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: fixed;
  border: 2px solid black;
  background-color: white;
  z-index: 3;
  top: 12.5%;
  @media (max-width: 600px) {
    width: 100%;
    height: 80px;
    flex-direction: row;
    top: 12%;
  }
`;
