import React, { useState } from "react";
import { Route, Routes } from "react-router-dom";
import { LinkRoute, SideBar } from "../../Components/Sidebar/Sidebar.style";
import ListAddress from "../../Container/ListAddressBook/ListAddressBook";

const SidebarComponent = ({
  setShowCreateAddress,
  setShowListAddress,
}: any) => {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleHomeClick = (e: any) => {
    e.preventDefault();
    setShowCreateAddress(false);
    setShowListAddress(true);
  };

  const handleCreateClick = (e: any) => {
    setIsSubmitted(true);
    e.preventDefault();
    setShowCreateAddress(true);
    setShowListAddress(false);
  };

  return (
    <SideBar>
      <React.Fragment>
        <LinkRoute onClick={(e) => handleHomeClick(e)} to="/home">
          Home
        </LinkRoute>
        <LinkRoute onClick={(e) => handleCreateClick(e)} to="/home">
          Create
        </LinkRoute>
        <LinkRoute to="/">Sign out</LinkRoute>
      </React.Fragment>

      <Routes>
        <Route element={<ListAddress />} path="/home"></Route>
        <Route
          element={<ListAddress isSubmitted={isSubmitted} />}
          path="/home"
        ></Route>
      </Routes>
    </SideBar>
  );
};
export default SidebarComponent;
