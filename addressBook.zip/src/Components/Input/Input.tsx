import { InputText } from "./Input.style";
const InputField = ({
  name,
  type,
  value,
  onChange,
  placeholder,
  className,
}: any) => {
  return (
    <div>
      <InputText
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={className}
      />
    </div>
  );
};

export default InputField;
