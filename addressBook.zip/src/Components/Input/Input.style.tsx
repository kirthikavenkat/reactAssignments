import styled from "styled-components";

export const InputText = styled.input.attrs(
  (props: { className: string }) => props
)`
  height: 35px;
  width: 100%;
  border: 1px solid gray;
  border-radius: 2px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 20px 10px 20px 20px;
  border: ${(props) => (props.className === "errorDiv" ? "1px solid red" : "")};
  @media (max-width: 713px) {
    width: 85%;
  }
`;
