import { toast } from "react-toastify";
const ToastComponent = (message: any) => {
  return (
    <>
      {toast.success(message, {
        position: toast.POSITION.TOP_RIGHT,
      })}
    </>
  );
};

export default ToastComponent;
