import { DropdownSelect } from "./Select.style";
const Select = ({
  name,
  onChange,
  options,
  required,
  value,
  disabled,
  className,
}: any) => {
  return (
    <DropdownSelect
      name={name}
      onChange={onChange}
      required={required}
      value={value}
      disabled={disabled}
      className={className}
    >
      {options.map((option: any) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </DropdownSelect>
  );
};

export default Select;
