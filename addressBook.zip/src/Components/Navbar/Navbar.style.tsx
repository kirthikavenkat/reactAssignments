import styled from "styled-components";

export const AddressBookImage = styled.img`
  width: 35px;
  height: 35px;
  padding-left: 20px;
`;
export const Heading1 = styled.h1`
  position: relative;
  left: 2%;
  color: black;
  @media (max-width: 485px) {
    height: full;
    font-size: x-large;
  }
  @media (max-width: 350px) {
    font-size: large;
  }
`;
export const Heading2 = styled.h2`
  position: fixed;
  color: black;
  right: 25px;
  @media (max-width: 485px) {
    font-size: large;
  }
  @media (max-width: 425px) {
    display: none;
  }
`;
export const Header = styled.div`
  display: flex;
  flex-direction: row;
  height: 12%;
  position: fixed;
  top: 0px;
  border: 2px solid black;
  box-shadow: 0px 0px 3px black;
  width: 100%;
  align-items: center;
  background-color: white;
  z-index: 4;
`;
export const Image = styled.img`
  width: 20px;
  height: 20px;
  position: fixed;
  right: 190px;
  @media (max-width: 425px) {
    right: 37%;
  }
  @media (max-width: 425px) {
    display: none;
  }
`;
