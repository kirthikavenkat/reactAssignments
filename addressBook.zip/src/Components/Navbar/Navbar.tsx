import AddressBook from "../../Assets/AddressBook.png";
import UserIcon from "../../Assets/UserIcon.svg";
import {
  AddressBookImage,
  Heading1,
  Heading2,
  Header,
  Image,
} from "../../Components/Navbar/Navbar.style";
const NavbarComponent = ({ setShowCreateAddress, setShowListAddress }: any) => {
  const handleLogoClick = () => {
    setShowCreateAddress(false);
    setShowListAddress(true);
  };
  return (
    <Header>
      <AddressBookImage
        onClick={(e) => {
          handleLogoClick();
        }}
        src={AddressBook}
      />
      <Heading1>Address Book</Heading1>
      <Image src={UserIcon}></Image>
      <Heading2>Welcome User</Heading2>
    </Header>
  );
};
export default NavbarComponent;
