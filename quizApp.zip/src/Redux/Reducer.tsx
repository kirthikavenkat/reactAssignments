import {
  SetName,
  ChangeCategory,
  ChangeDifficulty,
  ChangeScore,
  ChangeError,
  CheckNameValidity
} from "./ActionTypes";

const initialState = {
  name: "",
  category: 0,
  difficulty: "",
  score: 0,
  error: false,
  isNameValid: true,
};

const reducer = (state = initialState, action: any) => {
  switch (action.type) {
    case SetName:
      return {
        ...state,
        name: action.payload,
      };
    case ChangeDifficulty:
      return {
        ...state,
        difficulty: action.payload,
      };
    case ChangeCategory:
      return {
        ...state,
        category: action.payload,
      };
    case ChangeScore:
      return {
        ...state,
        score: action.payload,
      };
    case ChangeError:
      return {
        ...state,
        error: action.payload,
      };
    case CheckNameValidity:
      return {
        ...state,
        isNameValid: action.payload,
      };
    default:
      return state;
  }
};

export default reducer;
