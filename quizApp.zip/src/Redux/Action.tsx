import {
  SetName,
  ChangeCategory,
  ChangeDifficulty,
  ChangeScore,
  ChangeError,
  CheckNameValidity
} from "./ActionTypes";

export const handleNameChange = (payload: any) => ({
    type: SetName,
    payload,
  });
export const handleCategoryChange = (payload: any) => ({
  type: ChangeCategory,
  payload,
});
export const handleDifficultyChange = (payload: any) => ({
  type: ChangeDifficulty,
  payload,
});
export const handleScoreChange = (payload: any) => ({
  type: ChangeScore,
  payload,
});
export const handleErrorChange = (payload: any) => ({
  type: ChangeError,
  payload,
});
export const handleNameValidity = (payload: any) => ({
  type: CheckNameValidity,
  payload,
});
