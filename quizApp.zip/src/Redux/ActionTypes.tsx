export const SetName = "SetName";
export const ChangeCategory = "ChangeCategory";
export const ChangeDifficulty = "ChangeDifficulty";
export const ChangeScore = "ChangeScore";
export const ChangeError = "ChangeError";
export const CheckNameValidity = "CheckNameValidity"
