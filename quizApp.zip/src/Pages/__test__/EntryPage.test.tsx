import React from "react";
import { render, screen, fireEvent,waitFor, getByTestId } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import '@testing-library/jest-dom';
import {
  MemoryRouter,
  Route,
  Routes
} from "react-router-dom";
import store from "../../Redux/Store";
import EntryPage from "../EntryPage/EntryPage";
import exp from "constants";

test("Select fields values are set properly", () => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={React.createElement(EntryPage)} />
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const difficultySelect = screen.getByTestId("difficulty");
  userEvent.selectOptions(difficultySelect,'easy'||'medium'||'difficult');

  const categorySelect: HTMLSelectElement = screen.getByTestId("category");
  userEvent.selectOptions(categorySelect, '9');
  const categoryValue = parseInt(categorySelect.value);
  expect(categoryValue).toBeGreaterThanOrEqual(9);
  expect(categoryValue).toBeLessThanOrEqual(32);
});

test("Entry page elements renders correctly", () => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<EntryPage />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const titleElement = screen.queryByText("Dynamic Quiz");
  expect(titleElement).toBeInTheDocument();

  const nameInput = screen.getByRole("textbox");
  expect(nameInput).toBeInTheDocument();

  expect(screen.getByTestId(/difficulty/i)).toBeInTheDocument();
  expect(screen.getByTestId(/category/i)).toBeInTheDocument();

  const playButton = screen.getByRole("button", { name: /play/i });
  expect(playButton).toBeInTheDocument();

  const handlePlayClick = jest.fn();
  playButton.onclick = handlePlayClick;


  fireEvent.click(playButton);
  expect(handlePlayClick).toHaveBeenCalledTimes(1);

});

test("Empty fields are present", async () => {

  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<EntryPage />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  )
  const nameInput = screen.getByRole("textbox");
  const selectDifficulty = screen.getByTestId(/difficulty/i);
  const selectCategory = screen.getByTestId(/category/i);

  userEvent.type(nameInput,'')
  userEvent.selectOptions(selectDifficulty,'');
  userEvent.selectOptions(selectCategory, '');

  expect(nameInput).toHaveValue('');
  expect(selectDifficulty).toHaveValue('');
  expect(selectCategory).toHaveValue('0');

  const playButton = screen.getByRole("button", { name: /play/i });

  const handlePlayClick = jest.fn();
  playButton.onclick = handlePlayClick;
  userEvent.click(playButton)
})
test("Display warning if the fields are empty on button click",()=>{
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<EntryPage />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  )
  const playButton = screen.getByRole('button');
  userEvent.click(playButton);
  const warning = screen.getByText(/Please fill out all the fields/i);
  expect(warning).toBeInTheDocument();
  });
test("Remove warning if all the fields are present" , async() => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<EntryPage />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  )
  const nameInput = screen.getByRole("textbox");
  const selectDifficulty = screen.getByTestId(/difficulty/i);
  const selectCategory = screen.getByTestId(/category/i);

  userEvent.type(nameInput,'user')
  userEvent.selectOptions(selectDifficulty,'easy');
  userEvent.selectOptions(selectCategory, 'Art');

  expect(nameInput).toHaveValue('user');
  expect(selectDifficulty).toHaveValue('easy');
  expect(selectCategory).toHaveValue('25');


    const playButton = screen.getByRole('button');
    userEvent.click(playButton);
    expect(screen.queryByTestId(/emptyFields/i)).not.toBeInTheDocument();
  })

test("Display warning if the name is invalid",async ()=>{
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<EntryPage />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  )

  const nameInput = screen.getByRole("textbox");
  userEvent.type(nameInput, "");

  await waitFor(() => {
  const nameWarning =  screen.findByTestId("invalidName");
  expect(nameWarning).toBeInTheDocument;
  
  });
})