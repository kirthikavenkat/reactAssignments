import React from "react";
import { fireEvent, getByTestId, render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import store from "../../Redux/Store";
import MainPage from "../MainPage/MainPage";
import "@testing-library/jest-dom";
import { Modal } from "antd";
import { waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createMemoryHistory } from "history";
import { act } from "react-dom/test-utils";
import axios from "axios";
import {
  handleCategoryChange,
  handleDifficultyChange,
} from "../../Redux/Action";
import { shuffleOptions } from "../../Components/Question/QuestionCard";

// jest.mock("../../Components/Timer/Timer", () => {

//   const useEffect = require('react')
//   let time = 30;
//   const setTime = jest.fn().mockImplementation((newTime) => {
//     time = newTime;
//   });
//   const useTimer = () => {
//     const tick = () => {
//       if (time > 0) {
//         setTime(time - 1);
//         useEffect(() => {
//           const interval = setInterval(tick, 1000);
//           return () => clearInterval(interval);
//         }, []);
//       }
//     };
//     return [time];
//   };
//   return useTimer;
// });

test("Main page elements renders correctly", async () => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={["/home"]}>
        <Routes>
          <Route path="/home" element={React.createElement(MainPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );

  const questionText = await screen.findByTestId("questionText");
  expect(questionText).toBeInTheDocument();

  const questionProgress = await screen.findByTestId("questionProgress1");
  expect(questionProgress).toBeInTheDocument();

  const timerContainer = await screen.findByTestId("timerContainer");
  expect(timerContainer).toBeInTheDocument();

  const optionsContainer = await screen.findByTestId("optionsContainer");
  expect(optionsContainer).toBeInTheDocument();

  const actionButtons = await screen.findAllByRole("button");
  expect(actionButtons).toHaveLength(3);
});

test("renders the questions correctly", async () => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={["/home"]}>
        <Routes>
          <Route path="/home" element={React.createElement(MainPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  await waitFor(() => screen.getByTestId("questionText"));
  expect(screen.getByTestId("questionProgress1")).toBeInTheDocument();
});

jest.mock("antd", () => ({
  Modal: {
    confirm: jest.fn(),
  },
}));
const confirmMock = jest.spyOn(Modal, "confirm");

test("Move to entry page on click of quit", async () => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={["/home"]}>
        <Routes>
          <Route path="/home" element={React.createElement(MainPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );

  const history = createMemoryHistory();
  const quitButton = screen.getByTestId("quit");
  const handleQuitClick = jest.fn();
  quitButton.onclick = handleQuitClick;
  userEvent.click(quitButton);
  expect(handleQuitClick).toHaveBeenCalledTimes(1);
  expect(Modal.confirm).toHaveBeenCalledTimes(1);
  expect(Modal.confirm).toHaveBeenCalledWith({
    title: "Are you sure you want to quit?",
    okText: "Yes",
    okType: "danger",
    onOk: expect.any(Function),
  });
  const onOk = confirmMock.mock.calls[0][0].onOk;
  if (onOk) {
    onOk();
    expect(history.location.pathname).toBe("/");
  }
});

test("Move to next question on click of next", async () => {
  const { rerender } = render(
    <Provider store={store}>
      <MemoryRouter initialEntries={["/home"]}>
        <Routes>
          <Route path="/home" element={React.createElement(MainPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );

  const nextButton = screen.getByTestId("next");
  const handleNextClick = jest.fn();
  nextButton.onclick = handleNextClick;
  userEvent.click(nextButton);
  expect(handleNextClick).toHaveBeenCalledTimes(1);
  expect(Modal.confirm).toHaveBeenCalledTimes(1);
  expect(Modal.confirm).toHaveBeenCalledWith({
    title: "Are you sure you want to skip?",
    okText: "Yes",
    okType: "danger",
    onOk: expect.any(Function),
    onCancel: expect.any(Function),
  });
  const onOk = confirmMock.mock.calls[0][0].onOk;
  if (onOk) {
    onOk();
    rerender(
      <Provider store={store}>
        <MemoryRouter initialEntries={["/home"]}>
          <Routes>
            <Route path="/home" element={React.createElement(MainPage)}></Route>
          </Routes>
        </MemoryRouter>
      </Provider>
    );
    const nextQuestion = screen.getByTestId("questionProgress2");
    expect(nextQuestion).toBeInTheDocument();
  }
});

// test("Check the timer count", async () => {
//   const { rerender}=render(
//     <Provider store={store}>
//       <MemoryRouter initialEntries={["/home"]}>
//         <Routes>
//           <Route path="/home" element={React.createElement(MainPage)}></Route>
//         </Routes>
//       </MemoryRouter>
//     </Provider>
//   );
//   const timer = screen.getByTestId("timerCount");
//   expect(timer).toHaveTextContent("30")

// //   // Simulate 1 second passing
//   jest.advanceTimersByTime(1000);

//   rerender(<Provider store={store}>
//     <MemoryRouter initialEntries={["/home"]}>
//       <Routes>
//         <Route path="/home" element={React.createElement(MainPage)}></Route>
//       </Routes>
//     </MemoryRouter>
//   </Provider>)
//   await waitFor(() => {
//     expect(timer).toHaveTextContent("29");
//   });

// //   // Simulate another second passing
//   jest.advanceTimersByTime(1000);

//   rerender(<Provider store={store}>
//     <MemoryRouter initialEntries={["/home"]}>
//       <Routes>
//         <Route path="/home" element={React.createElement(MainPage)}></Route>
//       </Routes>
//     </MemoryRouter>
//   </Provider>)

//   await waitFor(() => {
//     expect(timer).toHaveTextContent("28");
//   });
// });
jest.mock("axios");

describe("MainPage", () => {
  it("should call the quiz API with the correct URL based on category and difficulty", async () => {
    const data = { results: ["question1", "question2", "question3"] };
    jest.spyOn(axios, "get").mockResolvedValueOnce({ data });

    const category = "9";
    const difficulty = "easy";
    let expectedUrl = `https://opentdb.com/api.php?amount=11`;

    expectedUrl += `&category=${category}`;
    expectedUrl += `&difficulty=${difficulty}`;
    expectedUrl += "&type=multiple";
    store.dispatch(handleCategoryChange(category));
    store.dispatch(handleDifficultyChange(difficulty));

    await act(async () => {
      render(
        <Provider store={store}>
          <MemoryRouter initialEntries={["/home"]}>
            <Routes>
              <Route path="/home" element={<MainPage />} />
            </Routes>
          </MemoryRouter>
        </Provider>
      );
    });
    expect(axios.get).toHaveBeenCalledWith(expectedUrl);
  });
});


// describe('shuffleOptions', () => {
//   it('should shuffle the options in a random order', () => {
//     const answers = ['option 1', 'option 2', 'option 3'];
//     const shuffleSpy = jest
//       .spyOn(module.exports, 'shuffleOptions' )
//       .mockImplementation((answers: any) => {
//         for (let i = answers.length - 1; i > 0; i--) {
//           const j = Math.floor(Math.random() * (i + 1));
//           [answers[i], answers[j]] = [answers[j], answers[i]];
//         }
//         return answers;
//       });
  
//     const shuffledAnswers = shuffleOptions(answers);
//     expect(shuffledAnswers).not.toEqual(answers);

//     shuffleSpy.mockRestore();
//   });
// });
