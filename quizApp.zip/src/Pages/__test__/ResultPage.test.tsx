import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import store from "../../Redux/Store";
import ResultPage from "../ResultPage/ResultPage";
import '@testing-library/jest-dom';
import userEvent from "@testing-library/user-event";
import { createMemoryHistory } from "history";

test("renders the score correctly", async() => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/result']}>
        <Routes>
          <Route path="/result" element={React.createElement(ResultPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const scoreCard = await screen.findByTestId("score");
  expect(scoreCard).toBeInTheDocument();
});
test("renders the score message correctly", async() => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/result']}>
        <Routes>
          <Route path="/result" element={React.createElement(ResultPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const scoreMessage = await screen.findByTestId("scoreMessage");
  expect(scoreMessage).toBeInTheDocument();
});


test("Button to navigate to entry page renders correctly", async() => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/result']}>
        <Routes>
          <Route path="/result" element={React.createElement(ResultPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const navigateButton = screen.getByRole('button');
  expect(navigateButton).toBeInTheDocument();
});
const history = createMemoryHistory();
test("Navigate to entry page on button click", async() => {
  render(
    <Provider store={store}>
      <MemoryRouter initialEntries={['/result']}>
        <Routes>
          <Route path="/result" element={React.createElement(ResultPage)}></Route>
        </Routes>
      </MemoryRouter>
    </Provider>
  );
  const navigateButton = screen.getByRole('button');
  const handleNavigateClick = jest.fn();
  navigateButton.onclick = handleNavigateClick;
  userEvent.click(navigateButton);
  expect(handleNavigateClick).toHaveBeenCalledTimes(1);
  expect(history.location.pathname).toBe("/");
});