import React from "react";
import { useSelector } from "react-redux";
import { stateType } from "../MainPage/MainPage";
import { Wrapper, ScoreCard , ResultContainer,PlayAgainButton} from "./ResultPage.style";
import { useNavigate } from "react-router-dom";

const ResultPage = () => {
  
  const {score , name , difficulty} = useSelector((state: stateType) => state);
  const navigate = useNavigate()
  const handlePlayAgain = () => {
    navigate("/")
  }
  return (
    <Wrapper>
      <ResultContainer>
        <ScoreCard data-testId="scoreMessage">{score > 5 ? (<>Congratulations {name}</>) : (<>Better luck next time {name}</>)}</ScoreCard>
        <ScoreCard data-testid="score">You scored {score}/10 in the {difficulty} level</ScoreCard>
      </ResultContainer>
      <PlayAgainButton onClick={handlePlayAgain}>Play Again</PlayAgainButton>
    </Wrapper>
  );
};

export default ResultPage;
