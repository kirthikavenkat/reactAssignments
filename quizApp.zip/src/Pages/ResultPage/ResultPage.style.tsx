import styled from "styled-components";

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #F7F7F7;
`;

export const ResultContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-bottom: 2rem;
`;

export const ScoreCard = styled.h3`
  font-size: 2rem;
  margin: 0;
  margin-bottom: 1rem;
  text-align: center;
  color: #5D5D5D;
`;

export const Quote = styled.h3`
  font-size: 2rem;
  margin: 0;
  text-align: center;
`;

export const PlayAgainButton = styled.button`
  background-color: #4CAF50;
  color: white;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 5px;
  font-size: 1.5rem;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background-color: #3e8e41;
  }
`;
