import styled from "styled-components";

export const FullContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin: auto;
  width: 100vw;
  height: 100vh;
  background-color: #f2f2f2;
`;

export const MainContainer = styled(FullContainer)`
  flex-direction: column;
  width: 25%;
  height: 60%;
  border: 1px solid black;
  border-radius: 3px;
  background-color: #fff;
  @media (max-width: 768px) {
    width: 80%;
  }
`;

export const InputText = styled.input`
  height: 2.1875rem;
  width: 86%;
  border: 1px solid;
  border-radius: 3px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 10px 10px;
  background-color: #fff;
  padding: 0px 0px 0px 4px;
  @media (max-width: 768px) {
    width: 70%;
  }
`;

export const PlayButton = styled.button`
  height: 2.1875rem;
  width: 87.5%;
  border: 1px solid;
  border-radius: 3px;
  outline: none;
  font-size: medium;
  box-shadow: none;
  margin: 10px 10px;
  background-color: #c4cdd3;
  cursor: pointer;
  @media (max-width: 768px) {
    width: 70%;
  }
`;

export const SelectTag = styled.select`
  height: 2.1875rem;
  width: 87.5%;
  border-radius: 3px;
  outline: none;
  font-size: 1rem;
  box-shadow: none;
  border: 1px solid;
  margin: 10px 10px;
  background-color: #fff;
  @media (max-width: 768px) {
    width: 70%;
  }
`;

export const ValidateWarning = styled.div`
  width: 100%;
  font-size: small;
  padding-left: 12%;
  color: #ff0000;
`;
