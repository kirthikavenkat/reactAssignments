import React from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { act } from "react-dom/test-utils";

import {
  InputText,
  FullContainer,
  MainContainer,
  PlayButton,
  SelectTag,
  ValidateWarning,
} from "./EntryPage.style";
import Categories from "../../Assets/Data/Categories";
import {
  handleCategoryChange,
  handleDifficultyChange,
  handleErrorChange,
  handleNameChange,
  handleNameValidity,
} from "../../Redux/Action";
import { stateType } from "../MainPage/MainPage";
const EntryPage = () => {
  const dispatch = useDispatch();


  const { name,category, difficulty, error ,isNameValid } = useSelector(
    (state: stateType) => state
  );
  
  const handleInputNameChange = (e:any) => {
    dispatch(handleNameChange(e.target.value));
    const nameRegex = /^([a-zA-Z]{1,29})+$/;
    if(nameRegex.test(e.target.value)){
      act(() => {
        dispatch(handleNameValidity(true));
      })
    }
    else{
      act(() => {
        dispatch(handleNameValidity(false));
      })
     
    }
  }

  const navigate = useNavigate();

  //check if all the fields are filled
  const handleSubmit = () => {
    if (name === "" || difficulty === "" || category === 0) {
      act(() => {
        dispatch(handleErrorChange(true));
      });
    } else {
      navigate("/home");
      act(() => {
        dispatch(handleErrorChange(false));
      })
      
    }
  };
  return (
    <FullContainer>
      <MainContainer>
        <h1>Dynamic Quiz</h1>
        {error && (
          <ValidateWarning className="warningMessage" data-testid="emptyFields">
            Please fill out all the fields
          </ValidateWarning>
        )}
        <InputText
          placeholder="Enter your name"
          value={name}
          onChange={handleInputNameChange}
        ></InputText>
        {!isNameValid && (
          <ValidateWarning data-testid="invalidName">Enter a valid name</ValidateWarning>
        )}
        <SelectTag
          name="difficulty"
          data-testid="difficulty"
          onChange={(e: any) => {
            dispatch(handleDifficultyChange(e.target.value));
          }}
        >
          <option
            value=""
            label="Select difficulty"
            style={{ pointerEvents: "none" }}
          ></option>
          <option value="easy" label="Easy"></option>
          <option value="medium" label="Medium"></option>
          <option value="difficult" label="Difficult"></option>
        </SelectTag>
        <SelectTag
          name="category"
          data-testid="category"
          onChange={(e: any) => {
            dispatch(handleCategoryChange(e.target.value));
          }}
        >
          <option
            value={0}
            label="Select category"
            style={{ pointerEvents: "none" }}
          ></option>
          {Categories &&
            Categories.map((category) => (
              <option key={category.category} value={category.value}>
                {category.category}
              </option>
            ))}
        </SelectTag>
        <PlayButton value="Play" name="Play" onClick={handleSubmit}>
          Play
        </PlayButton>
      </MainContainer>
    </FullContainer>
  );
};

export default EntryPage;
