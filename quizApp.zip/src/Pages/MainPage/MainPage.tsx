import QuestionCard from "../../Components/Question/QuestionCard";

export interface stateType {
  name: string;
  category: number;
  difficulty: string;
  score: number;
  error: boolean;
  isNameValid: boolean
}

const MainPage = () => {

  return (
    <div><QuestionCard/></div>
  )
};
export default MainPage;
