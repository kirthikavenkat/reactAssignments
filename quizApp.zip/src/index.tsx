import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import  {BrowserRouter,Route, Routes} from "react-router-dom";
import EntryPage from './Pages/EntryPage/EntryPage';
import MainPage from './Pages/MainPage/MainPage';
import ResultPage from './Pages/ResultPage/ResultPage';
import { Provider } from 'react-redux';
import store from './Redux/Store'
const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
  
);
root.render(
  <Provider store={store}>
      <BrowserRouter>
    <Routes>
      <Route path='/' element={<EntryPage/>}></Route>
      <Route path="/home" element={<MainPage/>}></Route>
      <Route path="/result" element={<ResultPage/>}></Route>
    </Routes>
  </BrowserRouter>
  </Provider>

);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

