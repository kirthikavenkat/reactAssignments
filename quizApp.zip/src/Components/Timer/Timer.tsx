import { useState, useEffect } from 'react';
const useTimer = (initialTime:any , pause:boolean, interval = 1000) => {
  const [time, setTime] = useState(initialTime);
  useEffect(() => {
    let timerId:any; 
    const tick = () => {
      setTime((prevTime:any) => prevTime - 1);
    };

    if (!pause && time > 0) {
      timerId = setInterval(tick, interval);
    }
    return () => {
      clearInterval(timerId);
    };
  }, [time, interval, pause]);

  return [time,setTime];
};

export default useTimer;
