import styled from "styled-components";

export const FullContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100vh;
  background-color: #f5f5f5;
  border-radius: 3px;
`;
export const QuestionProgress = styled.div`
  font-size: larger;
  @media (max-width: 768px) {
    width: 80%;
  }
`;
export const TimerIcon = styled.img`
  top: 7px;
`;
export const TimerContainer = styled.div`
  display: flex;
  font-size: medium;
  margin-top: 2px;
  margin-left: auto;
`;
export const QuizContainer = styled(FullContainer)`
  width: 30%;
  height: fit-content;
  background-color: #fff;
  padding: 0px 1.25rem;
  border: 1px solid;
  @media (max-width: 768px) {
    width: 80%;
  }
`;

export const QuestionContainer = styled.div`
  display: flex;
  flex-direction: row;
  background-color: #fff;
  padding: 1.25rem;
  width: 100%;
  @media (max-width: 380px) {
    padding: 0px;
  }
`;

export const QuestionText = styled.h2`
  text-align: center;
  margin-bottom: 0.75rem;
`;

export const OptionsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  background-color: #fff;
  @media (max-width: 768px) {
    width: 80%;
  }
`;

export const OptionButton = styled.button`
  margin: 5px;
  padding: 1.25rem;
  font-size: medium;
  background-color: #e6e6e6;
  border: none;
  border-radius: 3px;
  text-align: center;
  cursor: pointer;
  flex-basis: calc(50% - 1rem);
  @media (max-width: 768px) {
    flex-basis: 100%;
  }
`;
export const CorrectOptionButton = styled(OptionButton)`
  background-color: #28a745;
`;
export const IncorrectOptionButton = styled(OptionButton)`
  background-color: #dc3545;
`;
export const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  background-color: #fff;
  padding: 1.25rem;
`;

export const NextButton = styled.button`
  margin: 0.5rem;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: medium;
  width: 140px;
`;

export const QuitButton = styled(NextButton)`
  background-color: #dc3545;
`;
