import React, { useState, useEffect } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { Modal } from "antd";
import {
  CorrectOptionButton,
  IncorrectOptionButton,
  FullContainer,
  QuitButton,
  QuizContainer,
  QuestionContainer,
  QuestionProgress,
  QuestionText,
  OptionsContainer,
  OptionButton,
  ButtonContainer,
  NextButton,
  TimerContainer,
  TimerIcon,
} from "./MainPage.style";
import { useNavigate } from "react-router-dom";
import { handleScoreChange } from "../../Redux/Action";
import useTimer from "../../Components/Timer/Timer";
import { ToastContainer, toast } from "react-toastify";
import { decode } from "html-entities";
import "react-toastify/dist/ReactToastify.css";
import timerIcon from "../../Assets/timerIcon.svg";

export interface StateType {
  name: string;
  category: string;
  difficulty: string;
  score: number;
}
 //shuffling the options
export const shuffleOptions = (answers: any) => {
  for (let i = answers.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [answers[i], answers[j]] = [answers[j], answers[i]];
  }
  return answers;
};
const QuestionCard = () => {
  type Question = {
    category: string;
    type: string;
    difficulty: string;
    question: string;
    correct_answer: string;
    incorrect_answers: string[];
  };
  type QuestionsArray = Question[];

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { category, difficulty, score } = useSelector(
    (state: StateType) => state
  );

  const [questionNumber, setQuestionNumber] = useState(1);
  const [questions, setQuestions] = useState<QuestionsArray>([]);
  const [options, setOptions] = useState([""]);
  const [correctOption, setCorrectOption] = useState("");
  const [incorrectOption, setIncorrectOption] = useState("");
  const [pause, setPause] = useState(false);
  const [time, setTime] = useTimer(30, pause, 1000);

  //Api
  let quizUrl = "https://opentdb.com/api.php?amount=11";


    quizUrl += `&category=${category}`;
  
  
    quizUrl += `&difficulty=${difficulty}`;
  

  quizUrl += "&type=multiple";

  //fetch questions
  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const { data } = await axios.get(quizUrl);
        setQuestions(data.results);
        dispatch(handleScoreChange(0));
      } catch (error) {
        console.error("Failed to fetch questions:", error);
      }
    };
    fetchQuestions();
  }, [quizUrl, dispatch]);

  //Next button - function
  const handleNextClick = (e: any) => {
    e.preventDefault();
    if (questionNumber < 10) {
      if (correctOption === "") {
        Modal.confirm({
          title: "Are you sure you want to skip?",
          okText: "Yes",
          okType: "danger",
          onOk: () => {
            setQuestionNumber(questionNumber + 1);
            setCorrectOption("");
            setTime(30);
          },
          onCancel: () => {},
        });
      } else {
        setPause(false);
        setQuestionNumber(questionNumber + 1);
        setCorrectOption("");
        setTime(30);
      }
    } else {
      navigate("/result");
    }
  };

  //shuffling the options and setting them
  useEffect(() => {
    if (questions?.length) {
      const oneQuestion = questions[questionNumber];
      console.log("incorrect_answers", oneQuestion.incorrect_answers);
      if(oneQuestion.incorrect_answers){
        let answers = [
          ...oneQuestion.incorrect_answers,
          oneQuestion.correct_answer,
        ];
        answers = shuffleOptions(answers);
      setOptions(answers);
      }
      
    }
  }, [questions, questionNumber]);

 

  //dispatch score on answer click and display the correct answer and move to the next question
  const handleAnswerClick = (e: any) => {
    const question = questions[questionNumber];
    if (e.target.textContent === question.correct_answer) {
      dispatch(handleScoreChange(score + 1));
    } else {
      setIncorrectOption(e.target.textContent);
    }
    setCorrectOption(question.correct_answer);
    setPause(true);
  };

  //confirmation on click of quit button
  const handleQuit = () => {
    Modal.confirm({
      title: "Are you sure you want to quit?",
      okText: "Yes",
      okType: "danger",
      onOk: () => {
        navigate("/");
        dispatch(handleScoreChange(0));
      },
    });
  };

  //iterate question number when time hits 0
  useEffect(() => {
    if (time === 0) {
      if (questionNumber <= 10) {
        setQuestionNumber((prev) => prev + 1);
      } else {
        navigate("/result");
      }
      setTime(30);
    }
  }, [time, questionNumber, navigate, setTime]);

  //Warning notification when timer hits 10
  useEffect(() => {
    if (time === 10 && correctOption === "") {
      toast.warning("Only 10 seconds left", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  }, [time, correctOption]);

  return (
    <FullContainer>
      <ToastContainer />
        <QuizContainer>
          <QuestionContainer>
          <QuestionProgress data-testid={`questionProgress${questionNumber}`} >
              Question {questionNumber} / 10
            </QuestionProgress>
            <TimerContainer data-testid="timerContainer">
              <TimerIcon src={timerIcon}></TimerIcon>
              <div data-testid="timerCount">{time}</div>
            </TimerContainer>
          </QuestionContainer>
          <QuestionContainer>
            <QuestionText data-testid="questionText">
              {questions.length > 0 &&
                decode(questions[questionNumber]?.question)}
            </QuestionText>
          </QuestionContainer>

          <OptionsContainer data-testid="optionsContainer">
            {options.map((option: any, id: any) => {
              const isCorrectOption = option === correctOption;
              const isIncorrectOption = option === incorrectOption;
              return (
                <React.Fragment key={id}>
                  {isCorrectOption ? (
                    <CorrectOptionButton data-testid="correctOption"onClick={handleAnswerClick}>
                      {option}
                    </CorrectOptionButton>
                  ) : isIncorrectOption ? (
                    <IncorrectOptionButton onClick={handleAnswerClick}>
                      {option}
                    </IncorrectOptionButton>
                  ) : (
                    <OptionButton onClick={handleAnswerClick}>
                      {option}
                    </OptionButton>
                  )}
                </React.Fragment>
              );
            })}
          </OptionsContainer>
          <ButtonContainer>
            <QuitButton data-testid="quit" onClick={handleQuit}>Quit</QuitButton>
            <NextButton data-testid="next" onClick={handleNextClick}>Next</NextButton>
          </ButtonContainer>
        </QuizContainer>
    </FullContainer>
  );
};
export default QuestionCard;
