export{}

module.exports = {
preset: "ts-jest",
testEnvironment: 'jest-environment-jsdom',
verbose: true,
transform: {
"\\.(js|jsx|ts|tsx)$": "esbuild-jest",
},
"extensionsToTreatAsEsm": [".ts"],
globals: {
"ts-jest": {
tsconfig: "tsconfig.json",
},
}};