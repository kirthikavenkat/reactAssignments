import React from 'react';
import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store'
import PasswordValidationRules from '../Components/PasswordValidationRules/PasswordValidationRules';
import AnchorElTooltips from '../Components/PasswordValidationRules/PasswordValidationRules';

const mockStore = configureStore([]);

describe('PasswordValidationRules Component', () => {
  let store:any;

  beforeEach(() => {
    store = mockStore({
      upperCase: true,
      lowerCase: true,
      specialCharacter: true,
      digit: true,
      length: true,
    });
  });

  it('should render the validation rules with tick icons', () => {
    render(
      <Provider store={store}>
        <PasswordValidationRules />
      </Provider>
    );
    expect(screen.getByAltText('validIcon')).toBeInTheDocument();



    // Add more assertions for the tick icons and cross icons
  });
});

describe('AnchorElTooltips Component', () => {
  let store:any;

  beforeEach(() => {
    store = mockStore({
      upperCase: false,
      lowerCase: false,
      specialCharacter: false,
      digit: false,
      length: false,
    });
  });

  it('should render the validIcon when all validation rules are met', () => {
    render(
      <Provider store={store}>
        <AnchorElTooltips />
      </Provider>
    );

    expect(screen.getByAltText('informationIcon')).toBeInTheDocument();
  });

  it('should render the informationIcon when at least one validation rule is not met', () => {
    store = mockStore({
      upperCase: true,
      lowerCase: true,
      specialCharacter: false,
      digit: true,
      length: true,
    });

    render(
      <Provider store={store}>
        <AnchorElTooltips />
      </Provider>
    );

    expect(screen.getByAltText('informationIcon')).toBeInTheDocument();
  });


  // Add more test cases for different combinations of validation rule states
});

