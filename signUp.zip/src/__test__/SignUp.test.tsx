import React from "react";
import { render, screen , fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import SignUp from "../Pages/SignUp/SignUp";
import { Provider } from "react-redux";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import store from "../Redux/store";
import { handleUpperCase,handleLowerCase,handleDigit,handleLength,handleSpecialCharacter } from "../Redux/action";
import { debug } from "console";
import { act } from "react-dom/test-utils";
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
test("renders all the elements", () => {
  render(<Provider store={store}>
    <MemoryRouter>
      <Routes>
        <Route path="/" element={React.createElement(SignUp)}/>
      </Routes>
    </MemoryRouter>
  </Provider>);
  const inputFields = screen.getAllByRole("textbox");
  expect(inputFields).toHaveLength(2);
  const passwordField = screen.getByPlaceholderText("Password");
  expect(passwordField).toBeInTheDocument();
  const confirmPasswordField = screen.getByPlaceholderText("Confirm Password");
  expect(confirmPasswordField).toBeInTheDocument();
  const signUpButton = screen.getByRole("button")
  expect(signUpButton).toBeInTheDocument();
});

// test("displays required validation warning for firstname when submitted with empty value", () => {
//     render(<Provider store={store}>
//         <MemoryRouter>
//           <Routes>
//             <Route path="/" element={React.createElement(SignUp)}/>
//           </Routes>
//         </MemoryRouter>
//       </Provider>);
//     const submitButton = screen.getByRole("button");
//     fireEvent.click(submitButton);
//     const firstnameValidationWarning = screen.getByTestId(/firstNameWarn/i);
//     expect(firstnameValidationWarning).toBeInTheDocument();
//   });
//   test("displays invalid validation warning for firstname when submitted with invalid value", () => {
//     const { getByPlaceholderText } = render(<Provider store={store}>
//         <MemoryRouter>
//           <Routes>
//             <Route path="/" element={React.createElement(SignUp)}/>
//           </Routes>
//         </MemoryRouter>
//       </Provider>);
//     const firstnameInput = getByPlaceholderText("First Name");
//     const submitButton = screen.getByRole("button");

//     fireEvent.change(firstnameInput, { target: { value: "123" } });
//     const handleSignUpClick = jest.fn();
//     submitButton.onclick = handleSignUpClick;
//     fireEvent.click(submitButton);
//     expect(handleSignUpClick).toHaveBeenCalledTimes(1);
// debug();
//     fireEvent.click(submitButton)
//     const firstnameValidationWarning = screen.getByRole("alert");
//     expect(firstnameValidationWarning).toBeInTheDocument();
//   });
test("handlePasswordFocus sets viewPasswordRules to true", () => {
    render(<Provider store={store}>
      <MemoryRouter>
        <Routes>
          <Route path="/" element={React.createElement(SignUp)}/>
        </Routes>
      </MemoryRouter>
    </Provider>);
   const passwordInput = screen.getByPlaceholderText('Password');
   userEvent.tab();
   userEvent.type(passwordInput, '');
   expect(screen.getByRole('tooltip')).toBeInTheDocument();
  });


  test("handlePasswordKeyUp dispatches the expected actions", () => {

  

    render(<Provider store={store}>
      <MemoryRouter>
        <Routes>
          <Route path="/" element={React.createElement(SignUp)}/>
        </Routes>
      </MemoryRouter>
    </Provider>);
const passwordInput = screen.getByPlaceholderText('Password');
userEvent.type(passwordInput, 'Abcd123!'); // Enter a password value


// Assert that the dispatch functions are called with the expected values
act(()=>{

  store.dispatch(handleUpperCase(true));
})
act(()=>{

  store.dispatch(handleLowerCase(true));
})
act(()=>{
  store.dispatch(handleLength(true));
})
act(()=>{
  store.dispatch(handleDigit(true));
})
act(()=>{
  store.dispatch(handleSpecialCharacter(true));
})
  });

    test('renders successfully when username does not exist in localStorage', () => {
      
        
        render(<Provider store={store}>
      <MemoryRouter>
        <Routes>
          <Route path="/" element={React.createElement(SignUp)}/>
        </Routes>
      </MemoryRouter>
    </Provider>);
  
      // Assert that the component renders without any error message
      const errorMessage = screen.queryByText('Username already exists');
      expect(errorMessage).toBeNull();
    });
  
    // test('displays error message when username already exists in localStorage', () => {
    //   // Mock the localStorage data to simulate an existing username
    //   const existingUser = { firstname: 'John' };
    //   localStorage.setItem('User details', JSON.stringify([existingUser]));
  
    //      render(<Provider store={store}>
    //   <MemoryRouter>
    //     <Routes>
    //       <Route path="/" element={React.createElement(SignUp)}/>
    //     </Routes>
    //   </MemoryRouter>
    // </Provider>);
  
    //   // Assert that the component displays the error message
    //   const errorMessage = screen.getByText('Username already exists');
    //   expect(errorMessage).toBeInTheDocument();
    // });
    // jest.mock('react-hook-form', () => ({
    //   __esModule: true,
    //   useForm: jest.fn(),
    // }));

    // describe('SignUp component', () => {
    //   test('saves user data to localStorage on form submission', () => {
    //     const mockedSetItem = jest.spyOn(localStorage, 'setItem');
    //     useForm.mockReturnValue({
    //       register: jest.fn(),
    //       handleSubmit: handleSubmitMock,
    //     });
    //     const formData = {
    //       firstName: 'John',
    //       lastName: 'Doe',
    //       email: 'johndoe@example.com',
    //     };
    
    //     const handleSubmitMock = jest.fn((callback) => (e) => {
    //       e.preventDefault();
    //       callback(formData);
    //     });
    
       
    
    //     render(<SignUp />);
    
    //     // Simulate form submission
    //     const submitButton = screen.getByRole('button', { name: 'Submit' });
    //     fireEvent.click(submitButton);
    
    //     // Assert that localStorage.setItem was called with the expected data
    //     expect(mockedSetItem).toHaveBeenCalledWith(
    //       'User details',
    //       JSON.stringify([formData])
    //     );
    //   });
    // });