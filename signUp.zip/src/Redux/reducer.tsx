import { checkUpperCase,checkLowerCase,checkDigit,checkLength,checkSpecialCharacter } from "./actionTypes";
const initialState = {
    upperCase: false,
    lowerCase:false,
    digit: false,
    specialCharacter: false,
    length: false
}
const reducer = (state = initialState , action:any) => {
    switch (action.type) {
        case checkUpperCase:
          return {
            ...state,
            upperCase: action.payload,
          };
        case checkLowerCase:
           return {
              ...state,
              lowerCase: action.payload,
            };
        case checkDigit:
                return {
                  ...state,
                  digit: action.payload,
                };
        case checkSpecialCharacter:
                    return {
                      ...state,
                      specialCharacter: action.payload,
                    };
        case checkLength:
                        return {
                          ...state,
                          length: action.payload,
                        };
                        default:
                            return state;
} }

export default reducer;