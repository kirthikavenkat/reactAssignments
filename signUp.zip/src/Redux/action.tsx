import {
  checkDigit,
  checkLength,
  checkLowerCase,
  checkUpperCase,
  checkSpecialCharacter,
} from "./actionTypes";
export const handleUpperCase = (payload: any) => ({
  type: checkUpperCase,
  payload,
});
export const handleLowerCase = (payload: any) => ({
  type: checkLowerCase,
  payload,
});
export const handleDigit= (payload: any) => ({
  type: checkDigit,
  payload,
});
export const handleSpecialCharacter = (payload: any) => ({
  type: checkSpecialCharacter,
  payload,
});
export const handleLength = (payload: any) => ({
  type: checkLength,
  payload,
});
