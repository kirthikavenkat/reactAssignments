export const checkUpperCase = "checkUpperCase";
export const checkLowerCase = "checkLowerCase";
export const checkDigit = "checkDigit";
export const checkSpecialCharacter = "checkSpecialCharacter";
export const checkLength = "checkLength";
