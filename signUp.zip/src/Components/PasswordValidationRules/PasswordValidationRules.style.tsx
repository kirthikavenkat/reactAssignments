import styled from "styled-components";

export const ValidationRulesItem = styled.li.attrs(
  (props: { className: any }) => props
)`
  font-size: 13px;
  list-style: none;
  color: ${(props) => (props.className === false ? "#ff8f9e" : "#90EE90")};
`;
export const ListContainer = styled.div`
  display: flex;
  padding-right: 5%;
  margin-left: -15%;
  padding-bottom: 2%;
`;
