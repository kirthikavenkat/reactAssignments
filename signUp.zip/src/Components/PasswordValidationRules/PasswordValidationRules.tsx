import React from "react";
import { useSelector } from "react-redux";
import {Box, Tooltip} from "@mui/material";
import { Instance } from "@popperjs/core";
import {
  ListContainer,
  ValidationRulesItem,
} from "./PasswordValidationRules.style";
import crossIcon from "../../Assets/crossIcon.svg";
import informationIcon from "../../Assets/informationIcon.svg";
import tickIcon from "../../Assets/tickIcon.svg";
import validIcon from "../../Assets/validIcon.svg";


const PasswordValidationRules = () => {

  //data from redux store
  const { upperCase, lowerCase, specialCharacter, digit, length } = useSelector(
    (state: any) => state
  );
  return (
    <div>
      <ul>

        {/*Render the tick icon and cross icon if the validation rules are met and not met respectively*/}
        <ListContainer>
          {upperCase === true ? (
            <img alt="tickIcon" src={tickIcon}></img>
          ) : (
            <img alt="crossIcon" src={crossIcon}></img>
          )}{" "}
          <ValidationRulesItem className={upperCase}>
            At least 1 Upper case letter
          </ValidationRulesItem>
        </ListContainer>
        <ListContainer>
          {lowerCase === true ? (
            <img alt="tickIcon" src={tickIcon}></img>
          ) : (
            <img alt="crossIcon" src={crossIcon}></img>
          )}
          <ValidationRulesItem className={lowerCase}>
            At least 1 Lower case letter
          </ValidationRulesItem>
        </ListContainer>
        <ListContainer>
          {digit === true ? (
            <img alt="tickIcon" src={tickIcon}></img>
          ) : (
            <img alt="crossIcon" src={crossIcon}></img>
          )}
          <ValidationRulesItem className={digit}>
            At least 1 digit
          </ValidationRulesItem>
        </ListContainer>
        <ListContainer>
          {length === true ? (
            <img alt="tickIcon" src={tickIcon}></img>
          ) : (
            <img alt="crossIcon" src={crossIcon}></img>
          )}
          <ValidationRulesItem className={length}>
            At least length 8
          </ValidationRulesItem>
        </ListContainer>
        <ListContainer>
          {specialCharacter === true ? (
            <img alt="tickIcon" src={tickIcon}></img>
          ) : (
            <img alt="crossIcon" src={crossIcon}></img>
          )}
          <ValidationRulesItem className={specialCharacter}>
            At least 1 special character
          </ValidationRulesItem>
        </ListContainer>
      </ul>
    </div>
  );
};

const AnchorElTooltips = () => {
  const { upperCase, lowerCase, specialCharacter, digit, length } = useSelector(
    (state: any) => state
  );
  const isValid = upperCase && lowerCase && specialCharacter && digit && length;
  const positionRef = React.useRef<{ x: number; y: number }>({
    x: 0,
    y: 0,
  });
  const popperRef = React.useRef<Instance>(null);
  const areaRef = React.useRef<HTMLDivElement>(null);

  const handleMouseMove = (event: React.MouseEvent) => {
    positionRef.current = { x: event.clientX, y: event.clientY };

    if (popperRef.current != null) {
      popperRef.current.update();
    }
  };

  //Material UI tooltip
  return (
    <Tooltip
      role="tooltip"
      title={<PasswordValidationRules />}
      placement="top"
      arrow
      sx={{
        "& .MuiBox-root": {
          color: "white",
          border: "white 3px",
        },
      }}
      PopperProps={{
        popperRef,
        anchorEl: {
          getBoundingClientRect: () => {
            return new DOMRect(
              positionRef.current.x,
              areaRef.current!.getBoundingClientRect().y,
              0,
              0
            );
          },
        },
      }}
    >
      <Box
        ref={areaRef}
        onMouseMove={handleMouseMove}
        sx={{
          bgcolor: "transparent",
          color: "primary.contrastText",
          p: 1,
        }}
      >
        {isValid === true ? (
          <img alt="validIcon" src={validIcon}></img>
        ) : (
          <img alt="informationIcon" src={informationIcon}></img>
        )}
      </Box>
    </Tooltip>
  );
};
export default AnchorElTooltips;
