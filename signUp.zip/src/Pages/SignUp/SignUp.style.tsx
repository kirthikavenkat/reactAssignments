import styled, {css}from 'styled-components';

export const SignUpContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
  height: 100vh;
  background-color: #f2f2f2;
`;

export const SignUpWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  width: 80%;
  background-color: #ffffff;
  max-width: 1000px;
  border: 1px solid;
  box-shadow: 3px 1px 3px gray;
  @media (max-width: 768px) {
    flex-direction: column;
    justify-content: center;
    margin-top: 20px;
  }
`;

export const ImageContainer = styled.div`
  width: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  @media (max-width: 768px) {
    width: 100%;
  }
`;

export const SignUpImage = styled.img`
  max-width: 100%;
  max-height: 100%;
  @media (max-width: 768px) {
    max-height: 40vh;
  }

`;

export const SignUpForm = styled.form`
display: flex;
flex-direction: column;
align-items: center;
width: 50%;
border-left: 1px solid;
@media (max-width: 768px) {
  width: 100%;
  border-left: none;
}
`
export const InputField = styled.input`
padding: 10px;
margin-bottom: 10px;
border-radius: 5px;
border: 1px solid gray;
width: 100%;
outline: none;
@media only screen and (max-width: 768px) {
  width: 70%;
}
@media only screen and (min-width: 768px) {
  width: 60%;
}
`;
export const ValidateWarning = styled.div`
  width: 65%;
  font-size: small;
  color: #ff0000;
  margin-bottom: 3%;
  margin-top: -2%;
  @media only screen and (max-width: 768px) {
  width: 60%;
}
`;
export const SubmitButton = styled.button.attrs(
  (props: { className?: string }) => props
)`
  background-color: ${(props) => (props.className === "invalid" ? "red" : "green")};;
  color: white;
  padding: 10px 10px;
  border: none;
  border-radius: 5px;
  margin-top: 20px;
  left: 0;
`;
export const PasswordStrength = styled.div.attrs((props: { className?: any }) => props)`
display: flex;
width: 100%;
margin-left: 35%;
&:after {  
content: '';
border-radius: 2px;
margin-bottom: 5%;
width: ${props => props.className > 4 ? '65%' : props.className > 3 ? '40%' : '20%' };
height: 5px;
background-image: linear-gradient(to right, ${props => props.className > 4 ? 'green 100%' : props.className >3 ? 'orange 70%' : 'red 40%'});
box-shadow: 0px -10px 0px 0px ${props => props.className > 4 ? 'green' : props.className > 3 ? 'orange' : 'red'} inset;
} 
  `
export const ButtonContainer = styled.div.attrs(
  (props: { className: string }) => props
)`
display: flex;
justify-content: center;
align-items: center;
padding: 10px 40px 40px 40px;

  &:hover {
    ${({ className }) =>
      className === 'invalid' ?
     (css`
      transition: transform 0.4s ease-out alternate ;
        transform: translate(70px);
      `):(css`transform: none;`) }
  }
`

export const PasswordContainer = styled.div`
  display: flex;
  width: 100%;
  margin-left: 36.5%;
  height: 48px;

  @media (max-width: 767px) {
    margin-left: 26%;
  }
  @media (max-width: 414px) {
    margin-left: 23%;
  }
  @media (max-width: 320px) {
    margin-left: 22%;
  }

`