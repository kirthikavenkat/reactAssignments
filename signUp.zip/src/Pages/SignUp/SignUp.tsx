import { useState, useEffect }from "react";
import { useForm } from "react-hook-form";
import { useSelector, useDispatch } from "react-redux";
import signUp from "/Users/KirthikaVenkatesan/SignUp/signup/src/signUp.svg";
import AnchorElTooltips from "../../Components/PasswordValidationRules/PasswordValidationRules";
import {
  ButtonContainer,
  SignUpContainer,
  SignUpWrapper,
  ImageContainer,
  SignUpForm,
  SignUpImage,
  InputField,
  SubmitButton,
  ValidateWarning,
  PasswordContainer,
  PasswordStrength,
} from "./SignUp.style";
import {
  handleUpperCase,
  handleLowerCase,
  handleDigit,
  handleLength,
  handleSpecialCharacter,
} from "../../Redux/action";
const SignUp = () => {
 
 //states from redux
  const { upperCase, lowerCase, specialCharacter, digit, length } = useSelector(
    (state: any) => state
  );

  //set the strength of the password to use it for password strength meter
  const [strength, setStrength] = useState<any>(0);
  //update the strength
  useEffect(() => {
    let newStrength = 0;
    if (upperCase) newStrength++;
    if (lowerCase) newStrength++;
    if (specialCharacter) newStrength++;
    if (digit) newStrength++;
    if (length) newStrength++;
    setStrength(newStrength);
  }, [upperCase, lowerCase, specialCharacter, digit, length]);
  
  //useForm to handle the sign up form
  const {
    register,
    handleSubmit,
    trigger,
    watch,
    formState: { errors, isValid },
  } = useForm<userDetails>({ mode: "all" });

  interface userDetails {
    firstname: string;
    lastname: string;
    password: string;
    confirmPassword: string;
  }
  const dispatch = useDispatch();

  //state to set the data in local storage
  const [formData, setFormData] = useState<userDetails[]>([]);

  //state to track the password validation rules visibility
  const [viewPasswordRules, setViewPasswordRules] = useState(false);

  //on password focus display the password validation rules
  const handlePasswordFocus = (e: any) => {
    setViewPasswordRules(true);
    trigger("password");
  };
  
  //Password validation
  const handlePasswordKeyUp = (e: any) => {
    const { value } = e.target;
    trigger("password");
    const upperCaseCheck = /[A-Z]/.test(value);
    const lowerCaseCheck = /[a-z]/.test(value);
    const numberCheck = /[0-9]/.test(value);
    const passwordLengthCheck = value.length >= 8;
    const specialCharacterCheck = /[!@#$%^&*]/.test(value);

    dispatch(handleUpperCase(upperCaseCheck));
    dispatch(handleLowerCase(lowerCaseCheck));
    dispatch(handleLength(passwordLengthCheck));
    dispatch(handleDigit(numberCheck));
    dispatch(handleSpecialCharacter(specialCharacterCheck));
  };

  //hide the password validation rules on password field blur
  const handleBlur = () => {
    setViewPasswordRules(false);
    trigger("confirmPassword");
  };

  //watch the fields using useForm "watch"
  const firstname = watch("firstname");
  const password = watch("password");
  const confirmPassword = watch("confirmPassword");

  //check if password and confirm password are same
  const validatePasswordMatch = () => {
    if (confirmPassword !== password) {
      return "Passwords do not match";
    }
    return true;
  };

  //check if the username already exists in local storage
  const checkNameInLocalStorage = () => {
    const storedData = JSON.parse(localStorage.getItem("User details") || "[]");
    const isExisting = storedData.some(
      (item: any) => item.firstname === firstname
    );
    if (isExisting) {
      return "Username already exists";
    }
    return true;
  };

  //on submit of the form set the data in local storage
  const onSubmit = handleSubmit((data) => {
    setFormData((prevFormData) => {
      const newFormData = [...(prevFormData), data];
      localStorage.setItem("User details", JSON.stringify(newFormData));
      return newFormData;
    });
  });

  return (
    <SignUpContainer>
      <SignUpWrapper>
        <ImageContainer>
          <SignUpImage alt="Sign Up" src={signUp} />
        </ImageContainer>
        <SignUpForm onSubmit={onSubmit}>
          <h2>Sign Up</h2>
          <InputField
            {...register("firstname", {
              required: true,
              validate: checkNameInLocalStorage,
              pattern: {
                value: /^([a-zA-Z]{1,29})+$/,
                message: "",
              },
            })}
            placeholder="First Name"
          />
          {errors.firstname && errors.firstname.type === "required" && (
            <ValidateWarning role="alert">
              This field is required
            </ValidateWarning>
          )}
          {errors.firstname && errors.firstname.type === "pattern" && (
            <ValidateWarning>Invalid Firstname</ValidateWarning>
          )}
          {errors.firstname && errors.firstname.type === "validate" && (
            <ValidateWarning>{errors.firstname.message}</ValidateWarning>
          )}

          <InputField
            {...register("lastname", {
              required: true,
              pattern: {
                value: /^([a-zA-Z]{1,29})+$/,
                message: "Invalid lastname",
              },
            })}
            placeholder="Last Name"
          />
          {errors.lastname && errors.lastname.type === "required" && (
            <ValidateWarning>This field is required</ValidateWarning>
          )}
          {errors.lastname && errors.lastname.type === "pattern" && (
            <ValidateWarning>Invalid Lastname</ValidateWarning>
          )}
          <PasswordContainer>
            <InputField
              {...register("password", {
                required: true,
                validate: validatePasswordMatch,
              })}
              onFocus={handlePasswordFocus}
              onBlur={handleBlur}
              onKeyUp={handlePasswordKeyUp}
              placeholder="Password"
              type="password"
            />
            <AnchorElTooltips />
          </PasswordContainer>
          {viewPasswordRules && (
            <PasswordStrength
              role="passwordStrength"
              className={strength}
            ></PasswordStrength>
          )}
          {errors.password && errors.password.type === "required" && (
            <ValidateWarning>This field is required</ValidateWarning>
          )}

          <InputField
            {...register("confirmPassword", {
              required: true,
              validate: validatePasswordMatch,
            })}
            placeholder="Confirm Password"
            type="password"
          />
          {errors.confirmPassword &&
            errors.confirmPassword.type === "required" && (
              <ValidateWarning>This field is required</ValidateWarning>
            )}
          {errors.confirmPassword &&
            errors.confirmPassword.type === "validate" && (
              <ValidateWarning>
                {errors.confirmPassword.message}
              </ValidateWarning>
            )}

          <ButtonContainer
            className={isValid && strength > 4 ? "valid" : "invalid"}
          >
            <SubmitButton
              type="submit"
              className={isValid && strength > 4 ? "valid" : "invalid"}
            >
              Sign Up
            </SubmitButton>
          </ButtonContainer>
        </SignUpForm>
      </SignUpWrapper>
    </SignUpContainer>
  );
};

export default SignUp;
